STARSHIP TELEMETRY - mod KSP (overlay façon "Starship Flight")
================================================================

CONTENU
  GameData/StarshipTelemetry/   -> à copier dans <KSP>/GameData/ (REMPLACER l'ancien dossier)
  Source/                        -> code C# (à compiler, NE PAS mettre dans GameData)
  Tools/                         -> script qui régénère l'atlas (police D-DIN Bold, sprites)

COMPILER
  cd Source
  dotnet build -c Release "-p:KSPDir=C:\chemin\vers\Kerbal Space Program"
  -> StarshipTelemetry.dll arrive dans GameData/StarshipTelemetry/Plugins/

UTILISATION
  - La télémétrie est MASQUÉE au démarrage. En vol : icône de fusée dans le lanceur
    d'applications (barre d'icônes à droite) = afficher / masquer.
  - Panneau de contrôle : touche F10 (réglable) ou petit bouton ≡ en bas à droite de l'overlay.
      * Horloge : Auto (démarre quand le véhicule quitte le pad) / MET du jeu / Manuel (T- et compte à rebours)
      * Réinitialiser les jalons
      * "Écrire les moteurs détectés dans KSP.log" (outil de diagnostic)
  - F2 ne masque pas la télémétrie (option hideWithF2 dans le cfg).
  - Panneau de contrôle, 4 onglets :
      * Horloge   : nom de la mission, horloge Auto / MET du jeu / Manuel (T-)
      * Affichage : format Classic / Flight / Personnalisé, choix des 4 données
                    (tout à gauche, un peu à gauche, un peu à droite, tout à droite),
                    taille, opacité, bascule auto vers Flight après le landing de Super Heavy
      * Jalons    : cocher / décocher les jalons, régler leurs temps, ajouter des jalons personnalisés
      * Outils    : diagnostic moteurs (KSP.log)
  - Nom de la mission, taille et opacité se règlent dans le panneau de contrôle ; ils sont
    enregistrés dans GameData/StarshipTelemetry/PluginData/settings.cfg.

RÉGLAGES : GameData/StarshipTelemetry/StarshipTelemetry.cfg

POLICE : D-DIN Bold (Datto), licence SIL OFL 1.1 (voir D-DIN-OFL-1.1.txt).

NOTES DE VERSION (icônes et moteurs)
  - Icône d'inclinaison : Starship / Super Heavy / stack complet (stack tant que les deux ne sont pas séparés)
    dessinés en VRAI 3D (maillage ombré, orientation et roulis du véhicule), vus d'en haut comme sur la
    télémétrie SpaceX. Plus de sprites : tout est calculé dans le code (Source/TelemetryHUD.cs, BuildShip /
    BuildBooster pour changer les formes ou les couleurs).
  - Moteurs du ship : chaque moteur réel allume son propre point. Si le mauvais point s'allume, panneau de contrôle >
    Outils > "Pivoter" / "Miroir".
  - Cluster Andrada : modules OuterTwenty (20) / MiddleEight (8) / MiddleTwo (2) / CenterThree (3).
    Allumage : 3 = triangle central ; 5 = triangle + 2 ; 13 = triangle + anneau de 10 ; 33 = tout.
  - Diagnostic : "Écrire les moteurs détectés dans KSP.log" affiche aussi le masque des 33 points du booster
    et des 6 points du ship, ainsi que l'angle mesuré de chaque moteur du ship (angle=...).
  - Timeline : ligne droite au décollage, puis courbe progressive (cfg : curveAnimated, curveStartSec, curveEndSec).
