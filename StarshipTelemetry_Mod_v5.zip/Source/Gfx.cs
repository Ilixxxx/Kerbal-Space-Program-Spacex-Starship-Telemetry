using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEngine;

namespace StarshipTelemetry
{
    internal struct Spr
    {
        public float u0, v0, u1, v1;   // v0 = haut du sprite, v1 = bas
        public float x, y, w, h;       // pixels dans l'atlas (origine en haut à gauche)
    }

    internal class GlyphInfo
    {
        public float u0, v0, u1, v1;
        public float w, h, xoff, yoff, adv;
        public bool hasBitmap;
    }

    internal class FontSet
    {
        public int bakeSize;
        public float cap = 0.7f;
        public GlyphInfo[] glyphs = new GlyphInfo[128];
    }

    /// <summary>
    /// Rendu 2D par lots (GL immédiat) à partir d'un atlas unique :
    /// disques / anneaux / panneau anti-aliasés + police D-DIN Bold pré-calculée.
    /// Aucun texte IMGUI dynamique, aucune allocation par frame.
    /// </summary>
    internal class Gfx
    {
        public Texture2D tex;
        Material mat;
        float aw = 2048f, ah = 2048f;

        readonly Dictionary<string, Spr> sprs = new Dictionary<string, Spr>();
        readonly Dictionary<string, float> consts = new Dictionary<string, float>();
        readonly List<FontSet> fonts = new List<FontSet>();

        public float S = 1f; // échelle courante (pixels écran par pixel de design)

        Spr sWhite, sDS, sDM, sDL, sRingTrack, sRingFill, sRingHair, sTicks, sPanel;
        Spr sRocketShip, sRocketBooster, sRocketStack;
        float rocketH = 90f, rocketBodyH = 84f, rocketShipW = 40f, rocketBoosterW = 24f, rocketStackW = 20f;
        float ringCell, ringRho, dsCell, dsR, dmCell, dmR, dlCell, dlR;
        float whiteU, whiteV;

        static float F(string s) { return float.Parse(s, CultureInfo.InvariantCulture); }

        // ------------------------------------------------------------------
        public bool Load(string dir, out string error)
        {
            error = null;
            string png = Path.Combine(dir, "atlas.png");
            string txt = Path.Combine(dir, "atlas.txt");
            if (!File.Exists(png) || !File.Exists(txt)) { error = "atlas.png / atlas.txt introuvables dans " + dir; return false; }

            try
            {
                tex = new Texture2D(4, 4, TextureFormat.RGBA32, false);
                if (!tex.LoadImage(File.ReadAllBytes(png))) { error = "Impossible de lire atlas.png"; return false; }
                tex.filterMode = FilterMode.Bilinear;
                tex.wrapMode = TextureWrapMode.Clamp;
                tex.anisoLevel = 0;

                string[] lines = File.ReadAllLines(txt);
                // 1) en-tête + constantes
                for (int i = 0; i < lines.Length; i++)
                {
                    string[] t = lines[i].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    if (t.Length == 0) continue;
                    if (t[0] == "atlas") { aw = F(t[1]); ah = F(t[2]); }
                    else if (t[0] == "const") consts[t[1]] = F(t[2]);
                }
                // 2) sprites, polices, glyphes
                for (int i = 0; i < lines.Length; i++)
                {
                    string[] t = lines[i].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    if (t.Length == 0) continue;
                    if (t[0] == "spr")
                    {
                        sprs[t[1]] = MakeSpr(F(t[2]), F(t[3]), F(t[4]), F(t[5]));
                    }
                    else if (t[0] == "font")
                    {
                        int idx = int.Parse(t[1], CultureInfo.InvariantCulture);
                        while (fonts.Count <= idx) fonts.Add(new FontSet());
                        fonts[idx].bakeSize = int.Parse(t[2], CultureInfo.InvariantCulture);
                        fonts[idx].cap = F(t[3]);
                    }
                    else if (t[0] == "glyph")
                    {
                        int idx = int.Parse(t[1], CultureInfo.InvariantCulture);
                        int code = int.Parse(t[2], CultureInfo.InvariantCulture);
                        if (code < 0 || code >= 128) continue;
                        while (fonts.Count <= idx) fonts.Add(new FontSet());
                        GlyphInfo g = new GlyphInfo();
                        float x = F(t[3]), y = F(t[4]);
                        g.w = F(t[5]); g.h = F(t[6]);
                        g.xoff = F(t[7]); g.yoff = F(t[8]); g.adv = F(t[9]);
                        g.hasBitmap = g.w > 0 && g.h > 0;
                        g.u0 = x / aw; g.u1 = (x + g.w) / aw;
                        g.v0 = 1f - y / ah; g.v1 = 1f - (y + g.h) / ah;
                        fonts[idx].glyphs[code] = g;
                    }
                }

                sWhite = sprs["white"]; sDS = sprs["dS"]; sDM = sprs["dM"]; sDL = sprs["dL"];
                sRingTrack = sprs["ringTrack"]; sRingFill = sprs["ringFill"]; sRingHair = sprs["ringHair"]; sTicks = sprs["ticks"]; sPanel = sprs["panel"];
                ringCell = consts["ringCell"]; ringRho = consts["ringRho"];
                dsCell = consts["dsCell"]; dsR = consts["dsR"];
                dmCell = consts["dmCell"]; dmR = consts["dmR"];
                dlCell = consts["dlCell"]; dlR = consts["dlR"];
                sRocketShip = sprs["rocketShip"]; sRocketBooster = sprs["rocketBooster"]; sRocketStack = sprs["rocketStack"];
                rocketH = consts["rocketH"]; rocketBodyH = consts["rocketBodyH"];
                rocketShipW = consts["rocketShipW"]; rocketBoosterW = consts["rocketBoosterW"]; rocketStackW = consts["rocketStackW"];
                whiteU = (sWhite.u0 + sWhite.u1) * 0.5f;
                whiteV = (sWhite.v0 + sWhite.v1) * 0.5f;
                fonts.Sort(delegate (FontSet a, FontSet b) { return a.bakeSize.CompareTo(b.bakeSize); });
            }
            catch (Exception e)
            {
                error = "Erreur de chargement de l'atlas : " + e.Message;
                return false;
            }

            Shader sh = Shader.Find("Sprites/Default");
            if (sh == null) sh = Shader.Find("UI/Default");
            if (sh == null) sh = Shader.Find("Legacy Shaders/Particles/Alpha Blended");
            if (sh == null) { error = "Aucun shader compatible trouvé"; return false; }
            mat = new Material(sh);
            mat.hideFlags = HideFlags.HideAndDontSave;
            mat.mainTexture = tex;
            return true;
        }

        Spr MakeSpr(float x, float y, float w, float h)
        {
            Spr s = new Spr();
            s.x = x; s.y = y; s.w = w; s.h = h;
            s.u0 = x / aw; s.u1 = (x + w) / aw;
            s.v0 = 1f - y / ah; s.v1 = 1f - (y + h) / ah;
            return s;
        }

        public void Destroy()
        {
            if (mat != null) UnityEngine.Object.Destroy(mat);
            if (tex != null) UnityEngine.Object.Destroy(tex);
        }

        // ------------------------------------------------------------------
        public void Begin(float W, float H)
        {
            mat.mainTexture = tex;
            mat.SetPass(0);
            GL.PushMatrix();
            GL.LoadPixelMatrix(0, W, H, 0);
            GL.Begin(GL.QUADS);
        }

        public void End()
        {
            GL.End();
            GL.PopMatrix();
        }

        void V(float x, float y, float u, float v, Color c)
        {
            GL.Color(c);
            GL.TexCoord2(u, v);
            GL.Vertex3(x, y, 0f);
        }

        // ------------------------------------------------------------------
        //  Primitives pleines
        // ------------------------------------------------------------------
        public void Solid(float x0, float y0, float x1, float y1, Color c)
        {
            V(x0, y0, whiteU, whiteV, c); V(x1, y0, whiteU, whiteV, c);
            V(x1, y1, whiteU, whiteV, c); V(x0, y1, whiteU, whiteV, c);
        }

        /// <summary>
        /// Fusée ombrée orientée de la queue vers le nez. kind : 0 = ship, 1 = booster, 2 = stack.
        /// La longueur suit la distance tail-tip (raccourcie quand la fusée pointe vers l'écran), la largeur reste fixe.
        /// </summary>
        public void Rocket(int kind, Vector2 tail, Vector2 tip, Color tint)
        {
            Spr sp = kind == 0 ? sRocketShip : (kind == 1 ? sRocketBooster : sRocketStack);
            float wd = kind == 0 ? rocketShipW : (kind == 1 ? rocketBoosterW : rocketStackW);
            Vector2 d = tip - tail;
            float L = d.magnitude;
            if (L < 1f) return;
            Vector2 u = d / L;
            Vector2 n = new Vector2(-u.y, u.x);
            float Lq = L * (rocketH / rocketBodyH);
            float Wq = wd * S;
            Vector2 c = (tip + tail) * 0.5f;
            Vector2 tl = c + u * (Lq * 0.5f) - n * (Wq * 0.5f);
            Vector2 tr = c + u * (Lq * 0.5f) + n * (Wq * 0.5f);
            Vector2 br = c - u * (Lq * 0.5f) + n * (Wq * 0.5f);
            Vector2 bl = c - u * (Lq * 0.5f) - n * (Wq * 0.5f);
            V(tl.x, tl.y, sp.u0, sp.v0, tint);
            V(tr.x, tr.y, sp.u1, sp.v0, tint);
            V(br.x, br.y, sp.u1, sp.v1, tint);
            V(bl.x, bl.y, sp.u0, sp.v1, tint);
        }

        public void Quad(Vector2 a, Vector2 b, Vector2 c, Vector2 d, Color col)
        {
            V(a.x, a.y, whiteU, whiteV, col); V(b.x, b.y, whiteU, whiteV, col);
            V(c.x, c.y, whiteU, whiteV, col); V(d.x, d.y, whiteU, whiteV, col);
        }

        public void Tri(Vector2 a, Vector2 b, Vector2 c, Color col)
        {
            V(a.x, a.y, whiteU, whiteV, col); V(b.x, b.y, whiteU, whiteV, col);
            V(c.x, c.y, whiteU, whiteV, col); V(c.x, c.y, whiteU, whiteV, col);
        }

        public void SolidGrad(float x0, float y0, float x1, float y1, Color top, Color bottom)
        {
            V(x0, y0, whiteU, whiteV, top); V(x1, y0, whiteU, whiteV, top);
            V(x1, y1, whiteU, whiteV, bottom); V(x0, y1, whiteU, whiteV, bottom);
        }

        void SpriteQuad(Spr s, float x0, float y0, float x1, float y1, Color top, Color bottom, bool flipX)
        {
            float ua = flipX ? s.u1 : s.u0, ub = flipX ? s.u0 : s.u1;
            V(x0, y0, ua, s.v0, top); V(x1, y0, ub, s.v0, top);
            V(x1, y1, ub, s.v1, bottom); V(x0, y1, ua, s.v1, bottom);
        }

        /// <summary>Panneau sombre (coin arrondi + bord incliné). flipX = version miroir (droite).</summary>
        public void Panel(float x0, float y0, float x1, float y1, bool flipX, Color top, Color bottom)
        {
            SpriteQuad(sPanel, x0, y0, x1, y1, top, bottom, flipX);
        }

        /// <summary>Disque anti-aliasé de rayon r (pixels écran).</summary>
        public void Disc(Vector2 c, float r, Color col)
        {
            Spr s; float cell, R;
            float design = r / S;
            if (design < 9f) { s = sDS; cell = dsCell; R = dsR; }
            else if (design < 26f) { s = sDM; cell = dmCell; R = dmR; }
            else { s = sDL; cell = dlCell; R = dlR; }
            float half = r * (cell * 0.5f) / R;
            SpriteQuad(s, c.x - half, c.y - half, c.x + half, c.y + half, col, col, false);
        }

        // ------------------------------------------------------------------
        //  Anneaux 270° (écart en bas)
        // ------------------------------------------------------------------
        public void RingTrack(Vector2 c, float ringR, Color col)
        {
            float half = ringR * (ringCell * 0.5f) / ringRho;
            SpriteQuad(sRingTrack, c.x - half, c.y - half, c.x + half, c.y + half, col, col, false);
        }

        /// <summary>Cercle fin intérieur (hairline) des clusters.</summary>
        public void RingHair(Vector2 c, float ringR, Color col)
        {
            float half = ringR * (ringCell * 0.5f) / ringRho;
            SpriteQuad(sRingHair, c.x - half, c.y - half, c.x + half, c.y + half, col, col, false);
        }

        public void Ticks(Vector2 c, float ringR, Color col)
        {
            float half = ringR * (ringCell * 0.5f) / ringRho;
            SpriteQuad(sTicks, c.x - half, c.y - half, c.x + half, c.y + half, col, col, false);
        }

        /// <summary>Remplit l'anneau de 0 à frac (0..1) en secteurs texturés : arrondi parfait, bords nets.</summary>
        public void RingFill(Vector2 c, float ringR, float frac, Color col)
        {
            frac = Mathf.Clamp01(frac);
            if (frac <= 0.002f) return;

            float k = ringR / ringRho;                    // pixels écran par texel
            float total = 270f * frac;
            int n = Mathf.Max(1, Mathf.CeilToInt(total / 9f));
            float step = total / n;
            float rimTex = (ringRho + 14f) / Mathf.Cos(step * 0.5f * Mathf.Deg2Rad);

            float cxT = sRingFill.x + ringCell * 0.5f;
            float cyT = sRingFill.y + ringCell * 0.5f;
            float uc = cxT / aw, vc = 1f - cyT / ah;

            for (int i = 0; i < n; i++)
            {
                float a0 = (225f + step * i) * Mathf.Deg2Rad;
                float a1 = (225f + step * (i + 1)) * Mathf.Deg2Rad;
                float s0 = Mathf.Sin(a0), c0 = Mathf.Cos(a0), s1 = Mathf.Sin(a1), c1 = Mathf.Cos(a1);

                V(c.x, c.y, uc, vc, col);
                V(c.x + s0 * rimTex * k, c.y - c0 * rimTex * k, (cxT + s0 * rimTex) / aw, 1f - (cyT - c0 * rimTex) / ah, col);
                V(c.x + s1 * rimTex * k, c.y - c1 * rimTex * k, (cxT + s1 * rimTex) / aw, 1f - (cyT - c1 * rimTex) / ah, col);
                V(c.x + s1 * rimTex * k, c.y - c1 * rimTex * k, (cxT + s1 * rimTex) / aw, 1f - (cyT - c1 * rimTex) / ah, col);
            }
        }

        // ------------------------------------------------------------------
        //  Ligne anti-aliasée (dégradé d'opacité entre a et b)
        // ------------------------------------------------------------------
        public void AALine(Vector2 a, Vector2 b, float w, Color ca, Color cb)
        {
            Vector2 d = b - a;
            float len = d.magnitude;
            if (len < 0.0001f) return;
            d /= len;
            Vector2 n = new Vector2(-d.y, d.x);
            float h = Mathf.Max(0.6f, w * 0.5f);
            float o0 = h + 0.6f, o1 = h - 0.6f;
            if (o1 < 0f) o1 = 0f;
            Color a0 = new Color(ca.r, ca.g, ca.b, 0f), b0 = new Color(cb.r, cb.g, cb.b, 0f);

            // frange haute
            V(a.x + n.x * o0, a.y + n.y * o0, whiteU, whiteV, a0);
            V(a.x + n.x * o1, a.y + n.y * o1, whiteU, whiteV, ca);
            V(b.x + n.x * o1, b.y + n.y * o1, whiteU, whiteV, cb);
            V(b.x + n.x * o0, b.y + n.y * o0, whiteU, whiteV, b0);
            // coeur
            V(a.x + n.x * o1, a.y + n.y * o1, whiteU, whiteV, ca);
            V(a.x - n.x * o1, a.y - n.y * o1, whiteU, whiteV, ca);
            V(b.x - n.x * o1, b.y - n.y * o1, whiteU, whiteV, cb);
            V(b.x + n.x * o1, b.y + n.y * o1, whiteU, whiteV, cb);
            // frange basse
            V(a.x - n.x * o1, a.y - n.y * o1, whiteU, whiteV, ca);
            V(a.x - n.x * o0, a.y - n.y * o0, whiteU, whiteV, a0);
            V(b.x - n.x * o0, b.y - n.y * o0, whiteU, whiteV, b0);
            V(b.x - n.x * o1, b.y - n.y * o1, whiteU, whiteV, cb);
        }

        // ------------------------------------------------------------------
        //  Texte (D-DIN Bold pré-calculée)
        // ------------------------------------------------------------------
        FontSet PickFont(float px)
        {
            for (int i = 0; i < fonts.Count; i++)
                if (fonts[i].bakeSize >= px * 1.6f) return fonts[i];
            return fonts[fonts.Count - 1];
        }

        public float TextWidth(string t, float px, float track)
        {
            if (string.IsNullOrEmpty(t) || fonts.Count == 0) return 0f;
            FontSet f = PickFont(px);
            float sc = px / f.bakeSize, w = 0f;
            int n = 0;
            for (int i = 0; i < t.Length; i++)
            {
                char ch = t[i];
                if (ch >= 128) continue;
                GlyphInfo g = f.glyphs[ch];
                if (g == null) continue;
                w += g.adv * sc;
                n++;
            }
            if (n > 1) w += track * (n - 1);
            return w;
        }

        /// <summary>Texte centré en (cx, cy) ; px = taille de police finale en pixels écran ; angle en degrés (sens horaire).</summary>
        public void Text(string t, float cx, float cy, float px, Color col, float track, float angleDeg, bool shadow)
        {
            if (string.IsNullOrEmpty(t) || fonts.Count == 0) return;
            FontSet f = PickFont(px);
            float sc = px / f.bakeSize;
            float w = TextWidth(t, px, track);

            float rad = angleDeg * Mathf.Deg2Rad;
            float cs = Mathf.Cos(rad), sn = Mathf.Sin(rad);
            float baseline = f.cap * sc * 0.5f;   // centre optique = milieu des capitales

            if (shadow)
            {
                Color sc2 = new Color(0f, 0f, 0f, col.a * 0.55f);
                TextPass(t, f, sc, track, -w * 0.5f, baseline + Mathf.Max(1f, 1.4f * S), cx, cy, cs, sn, sc2);
            }
            TextPass(t, f, sc, track, -w * 0.5f, baseline, cx, cy, cs, sn, col);
        }

        void TextPass(string t, FontSet f, float sc, float track, float pen, float baseline,
                      float cx, float cy, float cs, float sn, Color col)
        {
            for (int i = 0; i < t.Length; i++)
            {
                char ch = t[i];
                if (ch >= 128) continue;
                GlyphInfo g = f.glyphs[ch];
                if (g == null) continue;
                if (g.hasBitmap)
                {
                    float x0 = pen + g.xoff * sc, y0 = baseline + g.yoff * sc;
                    float x1 = x0 + g.w * sc, y1 = y0 + g.h * sc;
                    V(cx + x0 * cs - y0 * sn, cy + x0 * sn + y0 * cs, g.u0, g.v0, col);
                    V(cx + x1 * cs - y0 * sn, cy + x1 * sn + y0 * cs, g.u1, g.v0, col);
                    V(cx + x1 * cs - y1 * sn, cy + x1 * sn + y1 * cs, g.u1, g.v1, col);
                    V(cx + x0 * cs - y1 * sn, cy + x0 * sn + y1 * cs, g.u0, g.v1, col);
                }
                pen += g.adv * sc + track;
            }
        }
    }
}
