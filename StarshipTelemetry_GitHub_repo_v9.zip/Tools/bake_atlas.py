#!/usr/bin/env python3
"""
Génère GameData/StarshipTelemetry/Textures/atlas.png + atlas.txt
(sprites anti-aliasés + police D-DIN Bold en 3 tailles).

Usage :  python bake_atlas.py [chemin/vers/Police-Bold.ttf]
Dépendances : pip install pillow numpy
"""
import os, sys, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
FONT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "D-DIN-Bold.ttf")
OUT = os.path.join(HERE, "..", "GameData", "StarshipTelemetry", "Textures")
os.makedirs(OUT, exist_ok=True)

AW = AH = 2048
FONT_SIZES = [32, 56, 112]

# ---- constantes partagées avec le plugin (en texels ; 1 px de design = 2 texels) ----
RING_CELL = 320
RING_RHO = 140.0          # rayon de la ligne médiane de l'anneau
RING_TRACK_T = 6.0        # épaisseur piste   (~2.9 px écran)
RING_FILL_T = 9.0         # épaisseur remplissage (~4.4 px écran)
FOOT_LEN = 18.0           # longueur du pied rentrant aux extrémités (9 px design)
TICK_W = 4.4
HAIR_RHO = 117.4          # cercle fin intérieur (57 px design pour un anneau de 68 px)
HAIR_T = 2.2
DS_CELL, DS_R = 32, 12.0
DM_CELL, DM_R = 72, 32.0
DL_CELL, DL_R = 256, 124.0
PANEL_W, PANEL_H = 1000, 360   # 500x180 px design


def down(a, ss):
    h, w = a.shape
    return a.reshape(h // ss, ss, w // ss, ss).mean(axis=(1, 3))


def grid(n, ss):
    m = n * ss
    c = (np.arange(m) + 0.5) / ss - n / 2.0
    return np.meshgrid(c, c)  # X droite, Y bas


def ring_mask(n, rho, thick, ss=4):
    X, Y = grid(n, ss)
    r = np.hypot(X, Y)
    ang = (np.degrees(np.arctan2(X, -Y)) + 360) % 360      # sens horaire depuis le haut
    a = (ang - 225) % 360
    m = (np.abs(r - rho) <= thick / 2) & (a <= 270)
    return down(m.astype(np.float32), ss)


def ticks_mask(n, rho, foot_len, width, ss=4):
    """Petits pieds rentrants aux deux extrémités de l'arc (début 100 %, fin 55 %)."""
    X, Y = grid(n, ss)
    r = np.hypot(X, Y)
    ang = np.degrees(np.arctan2(X, -Y)) % 360
    out = np.zeros_like(r)
    for a0, alpha in ((225.0, 1.0), (135.0, 0.55)):
        d = np.radians(((ang - a0 + 180) % 360) - 180)
        perp = np.abs(r * np.sin(d))
        along = r * np.cos(d)
        m = (perp <= width / 2) & (along >= rho - foot_len) & (along <= rho + RING_FILL_T / 2) & (np.cos(d) > 0)
        out = np.maximum(out, m * alpha)
    return down(out.astype(np.float32), ss)


def ring360_mask(n, rho, thick, ss=4):
    X, Y = grid(n, ss)
    r = np.hypot(X, Y)
    return down((np.abs(r - rho) <= thick / 2).astype(np.float32), ss)


def disc_mask(n, R, ss=8):
    X, Y = grid(n, ss)
    return down((np.hypot(X, Y) <= R).astype(np.float32), ss)


def panel_mask(ss=2):
    """Panneau 500x180 px design : bord haut droit, coin arrondi (r=30), bord droit incliné."""
    r = 30.0
    p0 = np.array([352.0, 0.0])
    d = np.array([144.0, 180.0]); d /= np.linalg.norm(d)
    n = np.array([-d[1], d[0]])                      # normale vers l'intérieur
    ay = r
    ax = p0[0] + (r - r * n[1]) / n[0]               # sommet du biseau rétréci
    mx, my = PANEL_W * ss, PANEL_H * ss
    xs = (np.arange(mx) + 0.5) / (2.0 * ss)
    ys = (np.arange(my) + 0.5) / (2.0 * ss)
    X, Y = np.meshgrid(xs, ys)
    inside = (Y >= r) & (((X - p0[0]) * n[0] + (Y - p0[1]) * n[1]) >= r)
    # distance au rayon 1 (vers la gauche) et au rayon 2 (le long du bord incliné)
    t1 = np.maximum(0.0, ax - X)
    d1 = np.hypot(X - (ax - t1), Y - ay)
    t2 = np.maximum(0.0, (X - ax) * d[0] + (Y - ay) * d[1])
    d2 = np.hypot(X - (ax + t2 * d[0]), Y - (ay + t2 * d[1]))
    m = inside | (np.minimum(d1, d2) <= r)
    return down(m.astype(np.float32), ss)


class Packer:
    def __init__(self, w, h, gap=3):
        self.w, self.h, self.gap = w, h, gap
        self.x = self.y = gap
        self.row_h = 0

    def add(self, w, h):
        if self.x + w + self.gap > self.w:
            self.x = self.gap
            self.y += self.row_h + self.gap
            self.row_h = 0
        if self.y + h + self.gap > self.h:
            raise RuntimeError("Atlas trop petit")
        pos = (self.x, self.y)
        self.x += w + self.gap
        self.row_h = max(self.row_h, h)
        return pos


atlas = np.zeros((AH, AW), dtype=np.float32)   # alpha
rgb_atlas = np.full((AH, AW, 3), 255, dtype=np.uint8)   # blanc, sauf sprites colorés
pk = Packer(AW, AH)
meta = ["atlas %d %d" % (AW, AH)]
consts = {
    "ringCell": RING_CELL, "ringRho": RING_RHO, "hairRho": HAIR_RHO,
    "dsCell": DS_CELL, "dsR": DS_R, "dmCell": DM_CELL, "dmR": DM_R,
    "dlCell": DL_CELL, "dlR": DL_R,
}
for k, v in consts.items():
    meta.append("const %s %s" % (k, v))


def put(name, mask):
    h, w = mask.shape
    x, y = pk.add(w, h)
    atlas[y:y + h, x:x + w] = mask
    meta.append("spr %s %d %d %d %d" % (name, x, y, w, h))


put("panel", panel_mask())
put("ringTrack", ring_mask(RING_CELL, RING_RHO, RING_TRACK_T))
put("ringFill", ring_mask(RING_CELL, RING_RHO, RING_FILL_T))
put("ticks", ticks_mask(RING_CELL, RING_RHO, FOOT_LEN, TICK_W))
put("ringHair", ring360_mask(RING_CELL, HAIR_RHO, HAIR_T))
put("dL", disc_mask(DL_CELL, DL_R))
put("dM", disc_mask(DM_CELL, DM_R))
put("dS", disc_mask(DS_CELL, DS_R))
put("white", np.ones((8, 8), dtype=np.float32))


# ---------------------------------------------------------------------------
#  Sprites de fusées (nez en haut), pour l'icône d'inclinaison
#  Tailles en px de design ; 1 px de design = 2 texels
# ---------------------------------------------------------------------------
ROCKET_H, ROCKET_BODY_H = 90, 84
ROCKET_W = {"ship": 40, "booster": 24, "stack": 20}
consts.update({"rocketH": ROCKET_H, "rocketBodyH": ROCKET_BODY_H,
               "rocketShipW": ROCKET_W["ship"], "rocketBoosterW": ROCKET_W["booster"], "rocketStackW": ROCKET_W["stack"]})
meta[:] = [m for m in meta if not m.startswith("const ")]
for k, v in consts.items():
    meta.append("const %s %s" % (k, v))


class Painter:
    def __init__(self, w, h, ss=4, K=2):
        self.sc = K * ss; self.ss = ss
        self.cw, self.ch = int(w * self.sc), int(h * self.sc)
        self.rgb = np.zeros((self.ch, self.cw, 3), np.float32)
        self.a = np.zeros((self.ch, self.cw), np.float32)
        xs = (np.arange(self.cw) + 0.5) / self.sc; ys = (np.arange(self.ch) + 0.5) / self.sc
        self.X, self.Y = np.meshgrid(xs, ys)

    def _mask_poly(self, pts):
        im = Image.new("L", (self.cw, self.ch), 0)
        ImageDraw.Draw(im).polygon([(x * self.sc, y * self.sc) for x, y in pts], fill=255)
        return np.asarray(im, np.float32) / 255.0

    def _mask_ell(self, x0, y0, x1, y1):
        im = Image.new("L", (self.cw, self.ch), 0)
        ImageDraw.Draw(im).ellipse([x0 * self.sc, y0 * self.sc, x1 * self.sc, y1 * self.sc], fill=255)
        return np.asarray(im, np.float32) / 255.0

    def solid(self, c):
        return lambda: np.broadcast_to(np.array(c, np.float32) / 255.0, (self.ch, self.cw, 3))

    def cyl(self, x0, x1, base):
        def f():
            t = np.clip((self.X - x0) / (x1 - x0), 0, 1)
            I = np.clip(0.60 + 0.40 * np.cos(np.pi * (t - 0.30)), 0, 1)
            return (np.array(base, np.float32) / 255.0)[None, None, :] * I[..., None]
        return f

    def _paint(self, m, colfn, alpha):
        m = m * alpha; col = colfn()
        self.rgb = self.rgb * (1 - m[..., None]) + col * m[..., None]
        self.a = self.a + m * (1 - self.a)

    def poly(self, pts, colfn, alpha=1.0): self._paint(self._mask_poly(pts), colfn, alpha)
    def ell(self, x0, y0, x1, y1, colfn, alpha=1.0): self._paint(self._mask_ell(x0, y0, x1, y1), colfn, alpha)
    def rect(self, x0, y0, x1, y1, colfn, alpha=1.0): self.poly([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], colfn, alpha)

    def result(self):
        ss = self.ss; h, w = self.ch // ss, self.cw // ss
        al = self.a.reshape(h, ss, w, ss).mean(axis=(1, 3))
        prem = (self.rgb * self.a[..., None]).reshape(h, ss, w, ss, 3).mean(axis=(1, 3))
        rgb = np.where(al[..., None] > 1e-4, prem / np.maximum(al[..., None], 1e-4), 0)
        mean = rgb[al > 0.5].mean(axis=0) if (al > 0.5).any() else np.array([1, 1, 1])
        rgb = np.where(al[..., None] > 1e-4, rgb, mean[None, None, :])     # évite les halos sur les bords
        return np.clip(rgb * 255, 0, 255).astype(np.uint8), al.astype(np.float32)


def ogive(cx, y_base, y_tip, half_w, n=14):
    pts_r = []
    for i in range(n + 1):
        t = i / n                       # 0 = base, 1 = pointe
        y = y_base + (y_tip - y_base) * t
        w = half_w * (1 - t ** 1.7) ** 0.55
        pts_r.append((cx + w, y))
    pts_l = [(2 * cx - x, y) for x, y in reversed(pts_r)]
    return pts_r + pts_l


def draw_ship(p):
    p.poly([(13, 60), (2.5, 68), (1.5, 83), (13, 81)], p.solid((214, 217, 224)))        # grands volets arrière
    p.poly([(27, 60), (37.5, 68), (38.5, 83), (27, 81)], p.solid((176, 179, 188)))
    p.poly([(13, 20), (7, 24), (6, 31), (13, 30)], p.solid((176, 179, 186)))            # petits volets avant
    p.poly([(27, 20), (33, 24), (34, 31), (27, 30)], p.solid((138, 141, 150)))
    p.rect(13, 15, 27, 84, p.cyl(13, 27, (244, 246, 250)))                              # corps
    p.rect(13, 37.4, 27, 38.4, p.solid((120, 122, 132)), 0.55)                          # joint
    p.poly(ogive(20, 15, 2.5, 7), p.cyl(13, 27, (62, 64, 70)))                          # ogive sombre
    p.rect(13, 84, 27, 87.5, p.solid((38, 40, 46)))                                     # jupe moteurs


def draw_booster(p):
    p.rect(1.5, 13, 6, 19, p.solid((62, 64, 70)))                                       # ailerons de grille
    p.rect(18, 13, 22.5, 19, p.solid((44, 46, 52)))
    p.rect(6, 10, 18, 86, p.cyl(6, 18, (242, 245, 249)))                                # corps
    p.rect(6, 17, 18, 18.8, p.solid((120, 122, 132)), 0.5)
    p.ell(6, 6.5, 18, 14.5, p.solid((68, 70, 76)))                                      # dessus sombre
    p.ell(7.6, 8, 16.4, 13, p.solid((150, 152, 160)))
    p.rect(6, 86, 18, 89.5, p.solid((38, 40, 46)))


def draw_stack(p):
    p.poly([(7, 18), (3.6, 21), (3.6, 26.5), (7, 25.5)], p.solid((172, 175, 182)))      # volets du ship
    p.poly([(13, 18), (16.4, 21), (16.4, 26.5), (13, 25.5)], p.solid((132, 135, 144)))
    p.rect(3.2, 33, 7, 37, p.solid((62, 64, 70)))                                       # ailerons de grille
    p.rect(13, 33, 16.8, 37, p.solid((44, 46, 52)))
    p.rect(7, 12, 13, 86, p.cyl(7, 13, (242, 245, 249)))                                # corps
    p.rect(7, 31, 13, 32.6, p.solid((110, 112, 122)), 0.7)                              # interface ship / booster
    p.poly(ogive(10, 12, 2.5, 3), p.cyl(7, 13, (62, 64, 70)))
    p.rect(7, 86, 13, 89.5, p.solid((38, 40, 46)))


def put_color(name, rgb, alpha):
    h, w = alpha.shape
    x, y = pk.add(w, h)
    atlas[y:y + h, x:x + w] = alpha
    rgb_atlas[y:y + h, x:x + w] = rgb
    meta.append("spr %s %d %d %d %d" % (name, x, y, w, h))


ICON_DIR = os.path.join(HERE, "icons")
CUSTOM_ICONS = {}
for nm, fn in (("rocketShip", draw_ship), ("rocketBooster", draw_booster), ("rocketStack", draw_stack)):
    kind = nm[6:].lower()
    png = os.path.join(ICON_DIR, "icon_%s.png" % kind)
    if os.path.exists(png):
        # silhouette fournie (extraite de la télémétrie SpaceX) : RGBA, nez en haut, intérieur opaque sombre
        arr = np.asarray(Image.open(png).convert("RGBA"))
        put_color(nm, arr[..., :3], arr[..., 3].astype(np.float32) / 255.0)
        CUSTOM_ICONS[kind] = 1
        continue
    pt = Painter(ROCKET_W[kind], ROCKET_H)
    fn(pt)
    c, a = pt.result()
    put_color(nm, c, a)

for k in CUSTOM_ICONS:
    meta.append("const icon%s 1" % k.capitalize())


# ---- polices ----
for idx, size in enumerate(sorted(FONT_SIZES, reverse=True)):
    pass
fonts_sorted = sorted(FONT_SIZES)
glyph_lines = []
for idx, size in enumerate(fonts_sorted):
    font = ImageFont.truetype(FONT, size)
    cap_bbox = font.getbbox("H", anchor="ls")
    cap = -cap_bbox[1]
    meta.append("font %d %d %.2f" % (idx, size, cap))
    pad = 2
    for code in range(33, 127):
        ch = chr(code)
        l, t, r, b = font.getbbox(ch, anchor="ls")
        w, h = r - l + 2 * pad, b - t + 2 * pad
        img = Image.new("L", (w, h), 0)
        ImageDraw.Draw(img).text((pad - l, pad - t), ch, font=font, fill=255, anchor="ls")
        x, y = pk.add(w, h)
        atlas[y:y + h, x:x + w] = np.asarray(img, dtype=np.float32) / 255.0
        glyph_lines.append("glyph %d %d %d %d %d %d %.2f %.2f %.3f" %
                           (idx, code, x, y, w, h, l - pad, t - pad, font.getlength(ch)))
    # espace : avance seulement
    glyph_lines.append("glyph %d %d 0 0 0 0 0 0 %.3f" % (idx, 32, font.getlength(" ")))

meta += glyph_lines

rgba = np.zeros((AH, AW, 4), dtype=np.uint8)
rgba[..., :3] = rgb_atlas
rgba[..., 3] = np.clip(atlas * 255.0 + 0.5, 0, 255).astype(np.uint8)
Image.fromarray(rgba, "RGBA").save(os.path.join(OUT, "atlas.png"), optimize=True)
with open(os.path.join(OUT, "atlas.txt"), "w") as f:
    f.write("\n".join(meta) + "\n")
print("OK ->", OUT, "| utilisé : %d%% de la hauteur" % int(100 * (pk.y + pk.row_h) / AH))
