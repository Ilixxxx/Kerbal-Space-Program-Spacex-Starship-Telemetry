using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEngine;
using KSP.UI.Screens;

namespace StarshipTelemetry
{
    public enum ClockMode { Auto = 0, GameMET = 1, Manual = 2 }
    public enum LayoutPreset { Classic = 0, Flight = 1, Custom = 2 }

    /// <summary>Données affichables dans un des 4 emplacements de la télémétrie.</summary>
    public enum Metric
    {
        None = 0,
        ShipGForce, ShipAttitude, ShipSpeed, ShipAltitude, ShipEngines,
        BoosterGForce, BoosterAttitude, BoosterSpeed, BoosterAltitude, BoosterEngines
    }

    /// <summary>
    /// Overlay de télémétrie façon "Starship Flight".
    /// 4 emplacements configurables (tout à gauche / un peu à gauche / un peu à droite / tout à droite),
    /// chrono T+, timeline courbe défilante, panneau de contrôle en jeu.
    /// Masqué par défaut ; activé via l'icône du lanceur d'applications.
    /// </summary>
    [KSPAddon(KSPAddon.Startup.Flight, false)]
    public class TelemetryHUD : MonoBehaviour
    {
        // =====================================================================
        //  RÉGLAGES (StarshipTelemetry.cfg, puis PluginData/settings.cfg)
        // =====================================================================
        static bool visible = false;
        static bool panelOpen = false;
        static bool configLoaded = false;
        static ClockMode clockMode = ClockMode.Auto;
        static int panelTab = 0;

        static string flightName = "STARSHIP FLIGHT 14";
        static string flightNameUp = "STARSHIP FLIGHT 14";
        static string[] boosterKeywords = new string[] { "andrada" };   // uniquement le cluster (pas "Behemoth BL-3 Core")
        static string[] shipSLKeywords = new string[] { "nagata" };
        static string[] shipVacKeywords = new string[] { "draper" };
        static string[] shipCoreKeywords = new string[] { "ship.core", "donnager" };
        static float minEngineThrust = 50f;          // kN : ignore les modules "Vents", hot-stage...
        static int shipEngineRotate = 0;             // correspondance moteurs du ship -> points de l'icône
        static bool shipEngineMirror = false;
        static bool curveAnimated = true;            // timeline droite au décollage puis courbe progressive
        static float curveStartSec = 20f, curveEndSec = 380f;
        static float boosterMaxSpeedKmh = 6500f;
        static float shipMaxSpeedKmh = 28000f;
        static float boosterMaxAltKm = 100f;
        static float shipMaxAltKm = 300f;
        static float maxG = 6f;
        static bool useOrbitalSpeed = false;
        static float uiScale = 1f;
        static float slotMargin = 145f;      // distance de l'emplacement extérieur au bord de l'écran (px de design)
        static float panelOpacity = 0.88f;
        static float timelinePxPerSec = 1.47f;
        static bool hideWithF2 = false;
        static KeyCode panelKey = KeyCode.F10;

        // affichage
        static LayoutPreset layoutPreset = LayoutPreset.Classic;
        static Metric[] slots = new Metric[] { Metric.BoosterEngines, Metric.BoosterSpeed, Metric.ShipSpeed, Metric.ShipEngines };
        static bool showVehicleLabels = true;
        static bool autoFlightAfterLanding = false;
        static bool secondCurve = false;

        static readonly string[] slotNames = { "Far left", "Left", "Right", "Far right" };
        static readonly string[] metricNames = {
            "None",
            "Ship - Force G", "Ship - Attitude icon", "Ship - Speed", "Ship - Altitude", "Ship - Engines",
            "Booster - Force G", "Booster - Attitude icon", "Booster - Speed", "Booster - Altitude", "Booster - Engines"
        };
        static readonly string[] presetNames = { "Classic (Super Heavy | Starship)", "Flight (ship only)", "Custom" };
        static readonly string[] tabNames = { "Clock", "Display", "Milestones", "Tools" };

        static void ApplyPreset(LayoutPreset p)
        {
            layoutPreset = p;
            if (p == LayoutPreset.Classic)
            {
                slots = new Metric[] { Metric.BoosterEngines, Metric.BoosterSpeed, Metric.ShipSpeed, Metric.ShipEngines };
                showVehicleLabels = true;
            }
            else if (p == LayoutPreset.Flight)
            {
                slots = new Metric[] { Metric.ShipSpeed, Metric.ShipAltitude, Metric.ShipAttitude, Metric.ShipEngines };
                showVehicleLabels = false;
            }
        }

        static string SettingsPath
        {
            get { return Path.Combine(KSPUtil.ApplicationRootPath, "GameData/StarshipTelemetry/PluginData/settings.cfg"); }
        }

        // ---------- plan de vol ----------
        class EventDef { public string name; public string type; public double time; public bool enabled = true; public bool custom = false; }
        static List<EventDef> eventDefs = DefaultEvents();

        static List<EventDef> DefaultEvents()
        {
            List<EventDef> l = new List<EventDef>();
            l.Add(new EventDef { name = "LIFTOFF", type = "liftoff", time = 0 });
            l.Add(new EventDef { name = "MAX Q", type = "maxq", time = 63 });
            l.Add(new EventDef { name = "STAGE SEP", type = "stagesep", time = 144 });
            l.Add(new EventDef { name = "BOOSTBACK START", type = "boostback", time = 160, enabled = false });
            l.Add(new EventDef { name = "BOOSTBACK SHUTDOWN", type = "boostbackend", time = 215, enabled = false });
            l.Add(new EventDef { name = "LANDING BURN", type = "landingburn", time = 395, enabled = false });
            l.Add(new EventDef { name = "SUPER HEAVY LANDING", type = "boosterlanding", time = 420 });
            l.Add(new EventDef { name = "SECO", type = "seco", time = 491 });
            l.Add(new EventDef { name = "ENTRY", type = "entry", time = 2820 });
            l.Add(new EventDef { name = "LANDING", type = "landing", time = 3900 });
            return l;
        }

        class TLEvent
        {
            public string name, nameUp, type, timeStr;
            public double planned;
            public double actual = -1;
            public bool enabled = true, custom = false;
        }
        readonly List<TLEvent> events = new List<TLEvent>();

        TLEvent MakeEvent(EventDef d)
        {
            TLEvent e = new TLEvent();
            e.name = d.name; e.nameUp = d.name.ToUpperInvariant();
            e.type = d.type; e.planned = d.time; e.timeStr = FormatEventTime(d.time);
            e.enabled = d.enabled; e.custom = d.custom;
            return e;
        }

        // actions différées (jamais de changement de structure pendant le dessin d'une fenêtre IMGUI)
        int pendingRemove = -1;
        bool pendingAdd = false, pendingRestoreEvents = false;
        string newEvName = "NEW EVENT", newEvTime = "10:00";
        Vector2 evScroll;

        // =====================================================================
        //  ÉTAT
        // =====================================================================
        ApplicationLauncherButton button;
        Texture2D icon;
        bool uiHidden = false;

        Gfx gfx;
        bool gfxOk = false;
        string gfxError = null;

        // horloge
        bool launched = false;
        double launchUT = 0;
        bool padSet = false;
        double padAlt = 0;
        double tPlus = 0;
        bool manRunning = false;
        double manBaseT = -600.0;
        double manBaseUT = 0;
        string tMinusInput = "10:00";

        // jalons
        double maxQ = 0;
        bool litAfterSep = false;
        bool boosterOffAfterSep = false;
        bool autoFlightDone = false;

        // ---- stats par véhicule chargé (recalculées à chaque scan) ----
        class VStats
        {
            public Vessel v;
            public bool hasBooster, hasShip;
            public int bTot, bAct;
            public bool[] mask = new bool[33];   // moteurs Super Heavy allumés, dans l'ordre des positions
            public bool[] shipMask = new bool[6];  // moteurs du ship allumés (0-2 gros VAC, 3-5 petits SL)
            public int slTot, slAct, vacTot, vacAct;
            public double bCur, bMax, sCur, sMax;
            public void Clear()
            {
                v = null; hasBooster = hasShip = false;
                bTot = bAct = slTot = slAct = vacTot = vacAct = 0;
                bCur = bMax = sCur = sMax = 0;
                Array.Clear(mask, 0, mask.Length);
                Array.Clear(shipMask, 0, shipMask.Length);
            }
            public float BFuel { get { return bMax > 0 ? (float)(bCur / bMax) : 0f; } }
            public float SFuel { get { return sMax > 0 ? (float)(sCur / sMax) : 0f; } }
        }
        readonly List<VStats> statPool = new List<VStats>();
        int statCount = 0;

        // ---- suivi PERSISTANT booster / ship (survit au déchargement physique de KSP) ----
        Vessel boosterV, shipV;
        readonly bool[] bMask = new bool[33];
        readonly bool[] sMask = new bool[6];
        int bLit = 0;
        int vacLit = 0, slLit = 0, vacTotLast = 0, slTotLast = 0;
        float bFuel = 0f, sFuel = 0f;
        float nextScan = 0f;

        // données affichables par véhicule
        class NumText
        {
            int key = int.MinValue;
            string str = "0";
            public string Int(double v)
            {
                int k = (int)Math.Round(v);
                if (k != key) { key = k; str = k.ToString(CultureInfo.InvariantCulture); }
                return str;
            }
            public string Dec(double v)
            {
                int k = (int)Math.Round(v * 10.0);
                if (k != key) { key = k; str = (k / 10.0).ToString("0.0", CultureInfo.InvariantCulture); }
                return str;
            }
            public string AltKm(double km)
            {
                int k = (int)Math.Round(km * 10.0);
                if (k != key)
                {
                    key = k;
                    str = km < 100.0 ? (k / 10.0).ToString("0.0", CultureInfo.InvariantCulture)
                                     : ((int)Math.Round(km)).ToString(CultureInfo.InvariantCulture);
                }
                return str;
            }
        }
        class VData
        {
            public double speedKmh, altKm, g;
            public float pitch = Mathf.PI * 0.5f;           // inclinaison du nez : 0 = vers l'aval (droite), 90° = vertical
            public NumText sp = new NumText(), alt = new NumText(), gt = new NumText();
        }
        readonly VData bData = new VData(), sData = new VData();

        // buffers réutilisés
        readonly List<ModuleEngines> tmpEngines = new List<ModuleEngines>();
        readonly List<Part> engParts = new List<Part>();
        readonly List<int> engKinds = new List<int>();
        readonly HashSet<string> boosterProps = new HashSet<string>();
        readonly HashSet<string> shipProps = new HashSet<string>();
        readonly Dictionary<Part, int> sideMap = new Dictionary<Part, int>();
        readonly Queue<Part> bfsQ = new Queue<Part>();
        readonly Dictionary<int, int> kindCache = new Dictionary<int, int>();

        // textes en cache
        int lastClockSec = int.MinValue;
        bool lastClockNeg = false;
        string clockStr = "00:00:00", clockPrefix = "T+";

        // mise en page
        float W, H, s, baseY, R, U, ringR;
        readonly float[] sx = new float[4];
        Rect btnRect;

        // fenêtre de contrôle
        static Rect windowRect = new Rect(80f, 80f, 410f, 0f);
        const int WindowId = 0x5D1A7;
        const string LockId = "StarshipTelemetryLock";
        bool inputLocked = false;
        static readonly string[] modeNames = { "Auto (motion)", "Game MET", "Manual" };

        // ---- géométrie des clusters (ordre = ordre d'allumage) ----
        // Mesurée sur la télémétrie SpaceX : triangle central (r≈9 px, pointe vers le bas),
        // anneau de 10 (r≈25.6, 18°+36°k), anneau de 20 (r≈42.8, 9°+18°k), points de ≈11.3 px
        static readonly Vector2[] raptorPos = BuildRaptorLayout();
        static readonly Vector2[] shipPos = {
            new Vector2(-0.46f, -0.27f), new Vector2(0.46f, -0.27f), new Vector2(0.00f, 0.53f),
            new Vector2(0.00f, -0.17f), new Vector2(-0.135f, 0.07f), new Vector2(0.14f, 0.07f)
        };
        static readonly float[] shipRad = { 0.25f, 0.25f, 0.25f, 0.10f, 0.10f, 0.10f };

        static readonly Color white = new Color(1f, 1f, 1f, 1f);
        static readonly Color dotOff = new Color(0.40f, 0.42f, 0.47f, 1f);

        // =====================================================================
        //  CYCLE DE VIE
        // =====================================================================
        void Start()
        {
            LoadConfig();
            foreach (EventDef d in eventDefs) events.Add(MakeEvent(d));

            gfx = new Gfx();
            string dir = Path.Combine(KSPUtil.ApplicationRootPath, "GameData/StarshipTelemetry/Textures");
            gfxOk = gfx.Load(dir, out gfxError);
            if (!gfxOk) Debug.LogError("[StarshipTelemetry] " + gfxError);

            icon = GameDatabase.Instance.GetTexture("StarshipTelemetry/Textures/icon", false);
            if (icon == null)
            {
                icon = new Texture2D(38, 38);
                Color[] px = new Color[38 * 38];
                for (int i = 0; i < px.Length; i++) px[i] = Color.white;
                icon.SetPixels(px);
                icon.Apply();
            }

            GameEvents.onGUIApplicationLauncherReady.Add(AddButton);
            GameEvents.onGUIApplicationLauncherDestroyed.Add(RemoveButton);
            GameEvents.onHideUI.Add(OnHideUI);
            GameEvents.onShowUI.Add(OnShowUI);

            if (ApplicationLauncher.Ready) AddButton();
        }

        void OnDestroy()
        {
            SaveSettings();
            GameEvents.onGUIApplicationLauncherReady.Remove(AddButton);
            GameEvents.onGUIApplicationLauncherDestroyed.Remove(RemoveButton);
            GameEvents.onHideUI.Remove(OnHideUI);
            GameEvents.onShowUI.Remove(OnShowUI);
            RemoveButton();
            if (inputLocked) { InputLockManager.RemoveControlLock(LockId); inputLocked = false; }
            if (gfx != null) gfx.Destroy();
        }

        void OnHideUI() { uiHidden = true; }
        void OnShowUI() { uiHidden = false; }

        void AddButton()
        {
            if (button != null || !ApplicationLauncher.Ready) return;
            button = ApplicationLauncher.Instance.AddModApplication(
                delegate { visible = true; },
                delegate { visible = false; },
                null, null, null, null,
                ApplicationLauncher.AppScenes.FLIGHT,
                icon);
            SyncButton();
        }

        void RemoveButton()
        {
            if (button != null && ApplicationLauncher.Instance != null)
                ApplicationLauncher.Instance.RemoveModApplication(button);
            button = null;
        }

        void SyncButton()
        {
            if (button == null) return;
            if (visible) button.SetTrue(false); else button.SetFalse(false);
        }

        // =====================================================================
        //  CONFIG + RÉGLAGES UTILISATEUR
        // =====================================================================
        static float F(string v, float def)
        {
            float f;
            return float.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out f) ? f : def;
        }

        static bool B(string v, bool def)
        {
            bool b;
            return bool.TryParse(v, out b) ? b : def;
        }

        static string[] SplitList(string v)
        {
            string[] k = v.Split(',');
            List<string> l = new List<string>();
            for (int i = 0; i < k.Length; i++)
            {
                string t = k[i].Trim().ToLowerInvariant();
                if (t.Length > 0) l.Add(t);
            }
            return l.ToArray();
        }

        static void SetFlightName(string n)
        {
            flightName = n;
            flightNameUp = n.ToUpperInvariant();
        }

        static List<EventDef> ParseEvents(ConfigNode n)
        {
            ConfigNode[] evs = n.GetNodes("EVENT");
            if (evs == null || evs.Length == 0) return null;
            List<EventDef> l = new List<EventDef>();
            foreach (ConfigNode en in evs)
            {
                if (!en.HasValue("name")) continue;
                string nm = en.GetValue("name");
                if (nm.Contains("=")) continue; // ancien cfg mono-ligne mal formé
                EventDef d = new EventDef();
                d.name = nm;
                d.type = en.HasValue("type") ? en.GetValue("type").Trim().ToLowerInvariant() : "none";
                d.time = en.HasValue("time") ? F(en.GetValue("time"), 0f) : 0;
                d.enabled = en.HasValue("enabled") ? B(en.GetValue("enabled"), true) : true;
                d.custom = en.HasValue("custom") ? B(en.GetValue("custom"), false) : false;
                l.Add(d);
            }
            return l.Count > 0 ? l : null;
        }

        void LoadConfig()
        {
            if (configLoaded) return;
            configLoaded = true;

            UrlDir.UrlConfig[] cfgs = GameDatabase.Instance.GetConfigs("STARSHIP_TELEMETRY");
            if (cfgs != null && cfgs.Length > 0)
            {
                ConfigNode n = cfgs[0].config;
                if (n.HasValue("flightName")) SetFlightName(n.GetValue("flightName"));
                if (n.HasValue("boosterKeywords")) boosterKeywords = SplitList(n.GetValue("boosterKeywords"));
                if (n.HasValue("shipSLKeywords")) shipSLKeywords = SplitList(n.GetValue("shipSLKeywords"));
                if (n.HasValue("shipVacKeywords")) shipVacKeywords = SplitList(n.GetValue("shipVacKeywords"));
                if (n.HasValue("shipCoreKeywords")) shipCoreKeywords = SplitList(n.GetValue("shipCoreKeywords"));
                if (n.HasValue("minEngineThrust")) minEngineThrust = Mathf.Max(0f, F(n.GetValue("minEngineThrust"), minEngineThrust));
                if (n.HasValue("curveAnimated")) curveAnimated = B(n.GetValue("curveAnimated"), curveAnimated);
                if (n.HasValue("curveStartSec")) curveStartSec = F(n.GetValue("curveStartSec"), curveStartSec);
                if (n.HasValue("curveEndSec")) curveEndSec = F(n.GetValue("curveEndSec"), curveEndSec);
                if (n.HasValue("boosterMaxSpeedKmh")) boosterMaxSpeedKmh = Mathf.Max(100f, F(n.GetValue("boosterMaxSpeedKmh"), boosterMaxSpeedKmh));
                if (n.HasValue("shipMaxSpeedKmh")) shipMaxSpeedKmh = Mathf.Max(100f, F(n.GetValue("shipMaxSpeedKmh"), shipMaxSpeedKmh));
                if (n.HasValue("boosterMaxAltKm")) boosterMaxAltKm = Mathf.Max(1f, F(n.GetValue("boosterMaxAltKm"), boosterMaxAltKm));
                if (n.HasValue("shipMaxAltKm")) shipMaxAltKm = Mathf.Max(1f, F(n.GetValue("shipMaxAltKm"), shipMaxAltKm));
                if (n.HasValue("maxG")) maxG = Mathf.Max(0.5f, F(n.GetValue("maxG"), maxG));
                if (n.HasValue("uiScale")) uiScale = Mathf.Clamp(F(n.GetValue("uiScale"), uiScale), 0.4f, 3f);
                if (n.HasValue("slotMargin")) slotMargin = Mathf.Clamp(F(n.GetValue("slotMargin"), slotMargin), 0f, 400f);
                if (n.HasValue("panelOpacity")) panelOpacity = Mathf.Clamp01(F(n.GetValue("panelOpacity"), panelOpacity));
                if (n.HasValue("timelinePxPerSec")) timelinePxPerSec = Mathf.Max(0.2f, F(n.GetValue("timelinePxPerSec"), timelinePxPerSec));
                if (n.HasValue("useOrbitalSpeed")) useOrbitalSpeed = B(n.GetValue("useOrbitalSpeed"), useOrbitalSpeed);
                if (n.HasValue("showOnStart")) visible = B(n.GetValue("showOnStart"), visible);
                if (n.HasValue("hideWithF2")) hideWithF2 = B(n.GetValue("hideWithF2"), hideWithF2);
                if (n.HasValue("controlPanelKey"))
                {
                    try { panelKey = (KeyCode)Enum.Parse(typeof(KeyCode), n.GetValue("controlPanelKey").Trim(), true); }
                    catch (Exception) { }
                }
                List<EventDef> l = ParseEvents(n);
                if (l != null) eventDefs = l;
            }

            LoadSettings(); // les réglages faits en jeu prennent le dessus
        }

        static void LoadSettings()
        {
            try
            {
                string path = SettingsPath;
                if (!File.Exists(path)) return;
                ConfigNode root = ConfigNode.Load(path);
                if (root == null) return;
                ConfigNode n = root.GetNode("STARSHIP_TELEMETRY_SETTINGS");
                if (n == null) return;

                if (n.HasValue("flightName")) SetFlightName(n.GetValue("flightName"));
                if (n.HasValue("uiScale")) uiScale = Mathf.Clamp(F(n.GetValue("uiScale"), uiScale), 0.4f, 3f);
                if (n.HasValue("panelOpacity")) panelOpacity = Mathf.Clamp01(F(n.GetValue("panelOpacity"), panelOpacity));
                if (n.HasValue("showVehicleLabels")) showVehicleLabels = B(n.GetValue("showVehicleLabels"), showVehicleLabels);
                if (n.HasValue("autoFlightAfterLanding")) autoFlightAfterLanding = B(n.GetValue("autoFlightAfterLanding"), autoFlightAfterLanding);
                if (n.HasValue("secondCurve")) secondCurve = B(n.GetValue("secondCurve"), secondCurve);
                if (n.HasValue("curveAnimated")) curveAnimated = B(n.GetValue("curveAnimated"), curveAnimated);
                if (n.HasValue("shipEngineMirror")) shipEngineMirror = B(n.GetValue("shipEngineMirror"), shipEngineMirror);
                if (n.HasValue("shipEngineRotate")) { int r; if (int.TryParse(n.GetValue("shipEngineRotate"), out r)) shipEngineRotate = ((r % 3) + 3) % 3; }
                if (n.HasValue("layoutPreset"))
                {
                    try { layoutPreset = (LayoutPreset)Enum.Parse(typeof(LayoutPreset), n.GetValue("layoutPreset"), true); }
                    catch (Exception) { }
                }
                for (int i = 0; i < 4; i++)
                {
                    string key = "slot" + i;
                    if (!n.HasValue(key)) continue;
                    try { slots[i] = (Metric)Enum.Parse(typeof(Metric), n.GetValue(key), true); }
                    catch (Exception) { }
                }
                List<EventDef> l = ParseEvents(n);
                if (l != null) eventDefs = l;
            }
            catch (Exception e) { Debug.LogWarning("[StarshipTelemetry] settings: " + e.Message); }
        }

        void SaveSettings()
        {
            try
            {
                // mémorise la liste de jalons modifiée en jeu pour les prochains vols
                List<EventDef> l = new List<EventDef>();
                for (int i = 0; i < events.Count; i++)
                {
                    TLEvent e = events[i];
                    l.Add(new EventDef { name = e.name, type = e.type, time = e.planned, enabled = e.enabled, custom = e.custom });
                }
                if (l.Count > 0) eventDefs = l;

                string path = SettingsPath;
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                ConfigNode root = new ConfigNode();
                ConfigNode n = root.AddNode("STARSHIP_TELEMETRY_SETTINGS");
                n.AddValue("flightName", flightName);
                n.AddValue("uiScale", uiScale.ToString("F2", CultureInfo.InvariantCulture));
                n.AddValue("panelOpacity", panelOpacity.ToString("F2", CultureInfo.InvariantCulture));
                n.AddValue("showVehicleLabels", showVehicleLabels.ToString());
                n.AddValue("autoFlightAfterLanding", autoFlightAfterLanding.ToString());
                n.AddValue("secondCurve", secondCurve.ToString());
                n.AddValue("curveAnimated", curveAnimated.ToString());
                n.AddValue("shipEngineMirror", shipEngineMirror.ToString());
                n.AddValue("shipEngineRotate", shipEngineRotate.ToString());
                n.AddValue("layoutPreset", layoutPreset.ToString());
                for (int i = 0; i < 4; i++) n.AddValue("slot" + i, slots[i].ToString());
                for (int i = 0; i < l.Count; i++)
                {
                    ConfigNode en = n.AddNode("EVENT");
                    en.AddValue("name", l[i].name);
                    en.AddValue("type", l[i].type);
                    en.AddValue("time", l[i].time.ToString("F0", CultureInfo.InvariantCulture));
                    en.AddValue("enabled", l[i].enabled.ToString());
                    en.AddValue("custom", l[i].custom.ToString());
                }
                root.Save(path);
            }
            catch (Exception e) { Debug.LogWarning("[StarshipTelemetry] save settings: " + e.Message); }
        }

        // =====================================================================
        //  JALONS
        // =====================================================================
        static string FormatEventTime(double sec)
        {
            int t = Mathf.Max(0, (int)Math.Round(sec));
            if (t >= 3600) return string.Format("{0}:{1:00}:{2:00}", t / 3600, (t / 60) % 60, t % 60);
            return string.Format("{0}:{1:00}", t / 60, t % 60);
        }

        bool Has(string type)
        {
            for (int i = 0; i < events.Count; i++)
                if (events[i].type == type && events[i].actual >= 0) return true;
            return false;
        }

        double ActualOf(string type)
        {
            for (int i = 0; i < events.Count; i++)
                if (events[i].type == type && events[i].actual >= 0) return events[i].actual;
            return -1;
        }

        void SetActual(string type)
        {
            for (int i = 0; i < events.Count; i++)
                if (events[i].type == type && events[i].actual < 0) events[i].actual = tPlus;
        }

        void ResetEvents()
        {
            for (int i = 0; i < events.Count; i++) events[i].actual = -1;
            maxQ = 0;
            litAfterSep = false;
            boosterOffAfterSep = false;
            autoFlightDone = false;
        }

        void AssumePastEvents()
        {
            for (int i = 0; i < events.Count; i++)
            {
                TLEvent e = events[i];
                if (e.type != "none" && e.type != "liftoff" && e.actual < 0 && e.planned < tPlus - 15.0)
                    e.actual = e.planned;
            }
        }

        // Un jalon jamais détecté 90 s après son heure prévue est considéré nominal (la timeline ne se bloque jamais)
        void AssumeOverdueEvents()
        {
            for (int i = 0; i < events.Count; i++)
            {
                TLEvent e = events[i];
                if (e.type != "none" && e.type != "liftoff" && e.actual < 0 && tPlus > e.planned + 90.0)
                    e.actual = e.planned;
            }
        }

        double EffTime(TLEvent e)
        {
            if (e.type == "liftoff") return 0;
            return e.actual >= 0 ? e.actual : e.planned;
        }

        bool IsReached(TLEvent e)
        {
            if (!launched) return false;
            return tPlus >= EffTime(e);
        }

        void ProcessPendingActions()
        {
            if (pendingRemove >= 0 && pendingRemove < events.Count) events.RemoveAt(pendingRemove);
            pendingRemove = -1;

            if (pendingAdd)
            {
                pendingAdd = false;
                double t;
                if (!TryParseTime(newEvTime, out t)) t = 600;
                EventDef d = new EventDef();
                d.name = string.IsNullOrEmpty(newEvName) ? "EVENT" : newEvName;
                d.type = "none"; d.time = Math.Max(0, t); d.enabled = true; d.custom = true;
                events.Add(MakeEvent(d));
            }

            if (pendingRestoreEvents)
            {
                pendingRestoreEvents = false;
                events.Clear();
                foreach (EventDef d in DefaultEvents()) events.Add(MakeEvent(d));
                ResetEvents();
            }
        }

        // =====================================================================
        //  HORLOGE
        // =====================================================================
        void DetectLiftoff(Vessel v, double ut)
        {
            if (!padSet)
            {
                padSet = true;
                padAlt = v.altitude;
                if (v.missionTime > 5.0 && v.situation != Vessel.Situations.PRELAUNCH && v.srfSpeed > 30.0)
                {
                    launched = true;
                    launchUT = ut - v.missionTime;
                    tPlus = v.missionTime;
                    AssumePastEvents();
                    return;
                }
            }
            if (v.verticalSpeed > 1.0 && v.altitude - padAlt > 1.0)
            {
                launched = true;
                launchUT = ut;
            }
        }

        double ManualValue(double ut)
        {
            return manRunning ? manBaseT + (ut - manBaseUT) : manBaseT;
        }

        void UpdateClock(Vessel v, double ut)
        {
            switch (clockMode)
            {
                case ClockMode.Auto:
                    if (!launched) DetectLiftoff(v, ut);
                    tPlus = launched ? ut - launchUT : 0.0;
                    break;
                case ClockMode.GameMET:
                    tPlus = Math.Max(0.0, v.missionTime);
                    launched = tPlus > 0.05;
                    break;
                default:
                    tPlus = ManualValue(ut);
                    launched = tPlus >= 0.0;
                    break;
            }
        }

        void OnModeChanged()
        {
            ResetEvents();
            launched = false;
            padSet = false;
            tPlus = 0;
        }

        static string FormatClock(double t)
        {
            bool neg = t < 0;
            int sec = neg ? (int)Math.Ceiling(-t) : (int)t;
            return (neg ? "T-" : "T+") + string.Format("{0:00}:{1:00}:{2:00}", sec / 3600, (sec / 60) % 60, sec % 60);
        }

        void RefreshClockStrings()
        {
            bool neg = tPlus < 0;
            int sec = neg ? (int)Math.Ceiling(-tPlus) : (int)tPlus;
            if (sec != lastClockSec || neg != lastClockNeg)
            {
                lastClockSec = sec; lastClockNeg = neg;
                clockPrefix = neg ? "T-" : "T+";
                clockStr = string.Format("{0:00}:{1:00}:{2:00}", sec / 3600, (sec / 60) % 60, sec % 60);
            }
        }

        // =====================================================================
        //  DÉTECTION MOTEURS / CARBURANT
        // =====================================================================
        static string NameOf(Part p)
        {
            return (p.partInfo != null ? (p.partInfo.name + " " + p.partInfo.title) : p.name).ToLowerInvariant();
        }

        static bool ContainsAny(string name, string[] kws)
        {
            for (int i = 0; i < kws.Length; i++)
                if (kws[i].Length > 0 && name.Contains(kws[i])) return true;
            return false;
        }

        // 0 = autre, 1 = booster (Andrada), 2 = ship SL (Nagata), 3 = ship VAC (Draper)
        int KindOf(Part p)
        {
            int id = p.GetInstanceID();
            int k;
            if (kindCache.TryGetValue(id, out k)) return k;
            string n = NameOf(p);
            if (ContainsAny(n, boosterKeywords)) k = 1;
            else if (ContainsAny(n, shipVacKeywords)) k = 3;
            else if (ContainsAny(n, shipSLKeywords)) k = 2;
            else k = 0;
            kindCache[id] = k;
            return k;
        }

        // Un moteur est "allumé" seulement s'il produit réellement de la poussée.
        // On ignore : modules désactivés (mode non sélectionné : leur état reste figé), véhicules "packed"
        // (hors portée physique : état figé), et véhicule sans gaz.
        static bool IsLit(ModuleEngines e, Vessel v)
        {
            if (v.packed) return false;
            if (!e.isEnabled) return false;
            if (v.ctrlState.mainThrottle <= 0.001f) return false;
            return e.EngineIgnited && !e.flameout && e.currentThrottle > 0.001f && e.finalThrust > 0.01f;
        }

        static readonly string[] numWords = {
            "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
            "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty"
        };

        // "Outer Twenty" -> 20, "Inner Three" -> 3, "Thirty-Three" -> 33 ... (0 si aucun mot)
        static int WordCount(string s)
        {
            if (string.IsNullOrEmpty(s)) return 0;
            string t = s.ToLowerInvariant();
            if (t.Contains("thirty") && t.Contains("three")) return 33;
            for (int k = numWords.Length - 1; k >= 1; k--)
                if (t.Contains(numWords[k])) return k;
            return 0;
        }

        static int EngineUnits(ModuleEngines e)
        {
            int w = WordCount(e.engineID);
            if (w > 0) return w;
            int tc = e.thrustTransforms != null ? e.thrustTransforms.Count : 0;
            if (tc > 0) return tc;
            return 1;
        }

        // Allume les points du cluster Super Heavy correspondant à un module de n moteurs.
        // Positions : 0-2 triangle, 3-12 anneau de 10 (3 et 4 = gauche/droite), 13-32 anneau de 20.
        static void MarkUnits(bool[] m, int n)
        {
            if (n >= 33) { for (int i = 0; i < 33; i++) m[i] = true; return; }
            if (n == 3) { for (int i = 0; i < 3; i++) m[i] = true; return; }
            if (n == 5) { for (int i = 0; i < 5; i++) m[i] = true; return; }
            if (n == 13) { for (int i = 0; i < 13; i++) m[i] = true; return; }
            if (n == 10) { for (int i = 3; i < 13; i++) m[i] = true; return; }
            if (n == 20) { for (int i = 13; i < 33; i++) m[i] = true; return; }
            if (n == 2) { m[3] = true; m[4] = true; return; }
            if (n == 8) { for (int i = 5; i < 13; i++) m[i] = true; return; }   // "MiddleEight" : le reste de l'anneau de 10
            int left = n;                                   // autre taille : remplissage dans l'ordre
            for (int i = 0; i < 33 && left > 0; i++) if (!m[i]) { m[i] = true; left--; }
        }

        static void AddProps(ModuleEngines e, HashSet<string> set)
        {
            if (e.propellants == null) return;
            for (int k = 0; k < e.propellants.Count; k++) set.Add(e.propellants[k].name);
        }

        VStats GetStat(int i)
        {
            while (statPool.Count <= i) statPool.Add(new VStats());
            return statPool[i];
        }

        // ---- moteurs du ship : chaque moteur réel allume SON point dans l'icône ----
        readonly List<Part> slParts = new List<Part>(), vacParts = new List<Part>();
        readonly Dictionary<int, int> shipDotCache = new Dictionary<int, int>();
        readonly Dictionary<int, float> shipAngDbg = new Dictionary<int, float>();
        static readonly int[] slDotOf = { 3, 5, 4 };     // angle 0°, 120°, 240° -> haut, bas-droite, bas-gauche
        static readonly int[] vacDotOf = { 1, 2, 0 };    // angle 60°, 180°, 300° -> haut-droite, bas, haut-gauche

        int DotOf(Part p)
        {
            int d;
            return shipDotCache.TryGetValue(p.GetInstanceID(), out d) ? d : -1;
        }

        Part FindShipCore(Vessel v)
        {
            for (int i = 0; i < v.parts.Count; i++)
                if (ContainsAny(NameOf(v.parts[i]), shipCoreKeywords)) return v.parts[i];
            return v.rootPart != null ? v.rootPart : v.parts[0];
        }

        static int Wrap3(int i) { return ((i % 3) + 3) % 3; }

        // Positions mesurées dans le repère de la pièce "corps du ship" (insensible au roulis) :
        // on déduit l'axe (normale du plan des moteurs), puis l'angle de chaque moteur autour de cet axe.
        void EnsureShipDots(Vessel v)
        {
            bool missing = false;
            for (int i = 0; i < slParts.Count && !missing; i++) if (!shipDotCache.ContainsKey(slParts[i].GetInstanceID())) missing = true;
            for (int i = 0; i < vacParts.Count && !missing; i++) if (!shipDotCache.ContainsKey(vacParts[i].GetInstanceID())) missing = true;
            if (!missing) return;

            Transform ct = FindShipCore(v).transform;
            int nSl = slParts.Count, nVac = vacParts.Count, total = nSl + nVac;
            Vector3[] lp = new Vector3[total];
            Vector3 centroid = Vector3.zero;
            for (int i = 0; i < total; i++)
            {
                Part pp = i < nSl ? slParts[i] : vacParts[i - nSl];
                lp[i] = ct.InverseTransformPoint(pp.transform.position);
                centroid += lp[i];
            }
            centroid /= total;

            // axe = normale du plan des moteurs (3 SL, sinon 3 VAC), orientée vers le corps du ship
            Vector3 nrm = Vector3.up;
            int a0 = nSl >= 3 ? 0 : (nVac >= 3 ? nSl : -1);
            if (a0 >= 0)
            {
                Vector3 cr = Vector3.Cross(lp[a0 + 1] - lp[a0], lp[a0 + 2] - lp[a0]);
                if (cr.sqrMagnitude > 1e-8f) nrm = cr.normalized;
            }
            if (centroid.sqrMagnitude > 1e-4f) { if (Vector3.Dot(nrm, -centroid) < 0f) nrm = -nrm; }
            else if (v.ReferenceTransform != null && Vector3.Dot(ct.TransformDirection(nrm), v.ReferenceTransform.up) < 0f) nrm = -nrm;

            // direction de référence ("haut" de l'icône) : un axe local de la pièce, perpendiculaire à l'axe
            Vector3[] axes = { Vector3.forward, Vector3.right, Vector3.up };
            int best = 0;
            float bd = 2f;
            for (int a = 0; a < 3; a++)
            {
                float dd = Mathf.Abs(Vector3.Dot(axes[a], nrm));
                if (dd < 0.3f) { best = a; break; }
                if (dd < bd) { bd = dd; best = a; }
            }
            Vector3 r = axes[best] - nrm * Vector3.Dot(axes[best], nrm);
            r.Normalize();
            Vector3 e2 = Vector3.Cross(nrm, r);

            float[] ang = new float[total];
            for (int i = 0; i < total; i++)
            {
                Vector3 d = lp[i] - centroid;
                float a = Mathf.Atan2(Vector3.Dot(d, e2), Vector3.Dot(d, r)) * Mathf.Rad2Deg;
                ang[i] = a < 0f ? a + 360f : a;
            }

            AssignDots(slParts, ang, 0, 0f, slDotOf);
            AssignDots(vacParts, ang, nSl, 60f, vacDotOf);
        }

        void AssignDots(List<Part> parts, float[] ang, int offset, float baseAngle, int[] dotOf)
        {
            int n = parts.Count;
            int[] idx = new int[n];
            bool[] used = new bool[3];
            bool dup = false;
            for (int i = 0; i < n; i++)
            {
                idx[i] = Wrap3(Mathf.RoundToInt((ang[offset + i] - baseAngle) / 120f));
                if (used[idx[i]]) dup = true;
                used[idx[i]] = true;
            }
            if (dup && n == 3)
            {
                // égalité : on range par angle croissant à partir du premier
                int[] ord = { 0, 1, 2 };
                System.Array.Sort(ord, delegate (int x, int y) { return ang[offset + x].CompareTo(ang[offset + y]); });
                int start = idx[ord[0]];
                for (int k = 0; k < 3; k++) idx[ord[k]] = Wrap3(start + k);
            }
            for (int i = 0; i < n; i++)
            {
                int k = shipEngineMirror ? Wrap3(3 - idx[i]) : idx[i];
                k = Wrap3(k + shipEngineRotate);
                shipDotCache[parts[i].GetInstanceID()] = dotOf[k];
                shipAngDbg[parts[i].GetInstanceID()] = ang[offset + i];
            }
        }

        void AssignSides()
        {
            sideMap.Clear();
            bfsQ.Clear();
            for (int i = 0; i < engParts.Count; i++)
            {
                Part p = engParts[i];
                if (!sideMap.ContainsKey(p)) { sideMap[p] = engKinds[i]; bfsQ.Enqueue(p); }
            }
            while (bfsQ.Count > 0)
            {
                Part c = bfsQ.Dequeue();
                int sd = sideMap[c];
                if (c.parent != null && !sideMap.ContainsKey(c.parent)) { sideMap[c.parent] = sd; bfsQ.Enqueue(c.parent); }
                for (int i = 0; i < c.children.Count; i++)
                {
                    Part ch = c.children[i];
                    if (ch != null && !sideMap.ContainsKey(ch)) { sideMap[ch] = sd; bfsQ.Enqueue(ch); }
                }
            }
        }

        void ScanVessels()
        {
            List<Vessel> loaded = FlightGlobals.VesselsLoaded;
            statCount = 0;
            VStats bestB = null, bestS = null;

            for (int vi = 0; vi < loaded.Count; vi++)
            {
                Vessel v = loaded[vi];
                if (v == null || v.parts == null) continue;
                VStats st = GetStat(statCount++);
                st.Clear();
                st.v = v;

                engParts.Clear(); engKinds.Clear();
                boosterProps.Clear(); shipProps.Clear();

                // pré-passe : moteurs du ship (pour allumer le bon point de l'icône)
                slParts.Clear(); vacParts.Clear();
                for (int i = 0; i < v.parts.Count; i++)
                {
                    int k0 = KindOf(v.parts[i]);
                    if (k0 == 2) slParts.Add(v.parts[i]); else if (k0 == 3) vacParts.Add(v.parts[i]);
                }
                if (slParts.Count + vacParts.Count > 0) EnsureShipDots(v);

                for (int i = 0; i < v.parts.Count; i++)
                {
                    Part p = v.parts[i];
                    tmpEngines.Clear();
                    for (int m = 0; m < p.Modules.Count; m++)
                    {
                        ModuleEngines me = p.Modules[m] as ModuleEngines;
                        if (me != null) tmpEngines.Add(me);
                    }
                    if (tmpEngines.Count == 0) continue;
                    int kind = KindOf(p);
                    if (kind == 0) continue;

                    int nSum = 0, nMax = 0, litMax = 0;
                    bool partLit = false;
                    for (int m = 0; m < tmpEngines.Count; m++)
                    {
                        ModuleEngines e = tmpEngines[m];
                        if (e.maxThrust < minEngineThrust) continue;      // "Vents", hot-stage... : pas de vrais moteurs
                        int n = EngineUnits(e);
                        nSum += n; if (n > nMax) nMax = n;
                        if (IsLit(e, v))
                        {
                            partLit = true;
                            if (n > litMax) litMax = n;
                            if (kind == 1) MarkUnits(st.mask, n);   // anneaux allumés simultanément
                        }
                        AddProps(e, kind == 1 ? boosterProps : shipProps);
                    }
                    if (nSum == 0) continue;

                    if (kind == 1)
                    {
                        st.hasBooster = true; st.bTot += nSum;
                    }
                    else
                    {
                        st.hasShip = true;
                        if (kind == 2) { st.slTot += nMax; st.slAct += litMax; }
                        else { st.vacTot += nMax; st.vacAct += litMax; }
                        if (partLit)
                        {
                            int dot;
                            if (shipDotCache.TryGetValue(p.GetInstanceID(), out dot)) st.shipMask[dot] = true;
                        }
                    }
                    engParts.Add(p);
                    engKinds.Add(kind == 1 ? 1 : 2);
                }

                if (st.hasBooster)
                {
                    int c = 0;
                    for (int i = 0; i < 33; i++) if (st.mask[i]) c++;
                    st.bAct = c;
                }

                // carburant : chaque pièce est attribuée au côté dont les moteurs sont les plus proches
                bool both = st.hasBooster && st.hasShip;
                if (both) AssignSides();
                if (st.hasBooster || st.hasShip)
                {
                    for (int i = 0; i < v.parts.Count; i++)
                    {
                        Part p = v.parts[i];
                        int side;
                        if (both) { if (!sideMap.TryGetValue(p, out side)) side = 1; }
                        else side = st.hasBooster ? 1 : 2;
                        HashSet<string> props = side == 1 ? boosterProps : shipProps;
                        for (int r = 0; r < p.Resources.Count; r++)
                        {
                            PartResource res = p.Resources[r];
                            if (!props.Contains(res.resourceName)) continue;
                            if (side == 1) { st.bCur += res.amount; st.bMax += res.maxAmount; }
                            else { st.sCur += res.amount; st.sMax += res.maxAmount; }
                        }
                    }
                }

                if (st.hasBooster)
                {
                    int sc = st.bTot + (st.v == boosterV ? 1000 : 0);
                    int bs = bestB == null ? -1 : bestB.bTot + (bestB.v == boosterV ? 1000 : 0);
                    if (sc > bs) bestB = st;
                }
                if (st.hasShip)
                {
                    int sc = st.slTot + st.vacTot + (st.v == shipV ? 1000 : 0);
                    int bs = bestS == null ? -1 : bestS.slTot + bestS.vacTot + (bestS.v == shipV ? 1000 : 0);
                    if (sc > bs) bestS = st;
                }
            }

            // ---- mise à jour du suivi persistant ----
            if (bestB != null)
            {
                boosterV = bestB.v;
                Array.Copy(bestB.mask, bMask, 33);
                bLit = bestB.bAct;
                bFuel = bestB.BFuel;
            }
            else if (boosterV != null)
            {
                Array.Clear(bMask, 0, 33); bLit = 0;       // déchargé : ses moteurs ne peuvent pas brûler
                if (boosterV.loaded) boosterV = null;      // chargé mais sans moteur booster : ce n'est plus lui
            }

            if (bestS != null)
            {
                shipV = bestS.v;
                Array.Copy(bestS.shipMask, sMask, 6);
                vacLit = (sMask[0] ? 1 : 0) + (sMask[1] ? 1 : 0) + (sMask[2] ? 1 : 0);
                slLit = (sMask[3] ? 1 : 0) + (sMask[4] ? 1 : 0) + (sMask[5] ? 1 : 0);
                vacTotLast = bestS.vacTot;
                slTotLast = bestS.slTot;
                sFuel = bestS.SFuel;
            }
            else if (shipV != null)
            {
                vacLit = 0; slLit = 0;
                Array.Clear(sMask, 0, 6);
                if (shipV.loaded) shipV = null;
            }
        }

        // Vitesse d'un véhicule, y compris DÉCHARGÉ (calculée sur son orbite)
        static double SpeedOfAny(Vessel v, double ut)
        {
            if (v == null) return 0.0;
            try
            {
                if (v.loaded) return (useOrbitalSpeed ? v.obt_speed : v.srfSpeed) * 3.6;
                if (v.Landed || v.Splashed) return 0.0;
                if (v.orbit == null) return 0.0;
                Vector3d vel = v.orbit.getOrbitalVelocityAtUT(ut);
                if (useOrbitalSpeed) return vel.magnitude * 3.6;
                Vector3d worldPos = v.mainBody.position + v.orbit.getRelativePositionAtUT(ut).xzy;
                Vector3d srf = vel.xzy - v.mainBody.getRFrmVel(worldPos);
                return srf.magnitude * 3.6;
            }
            catch (Exception)
            {
                return v.srfSpeed * 3.6;
            }
        }

        // Inclinaison du nez dans le plan vertical de la trajectoire (icône 2D façon SpaceX) :
        // 0 = nez vers l'aval (à droite de l'icône), 90° = vertical, > 90° = nez vers l'amont (retour du booster).
        // L'aval est la direction horizontale de la vitesse mesurée peu après le décollage (puis figée).
        static bool bearingSet = false;
        static double downBearing = Math.PI * 0.5;     // radians depuis le nord vers l'est (est par défaut)

        static float PitchOf(Vessel v, float prev)
        {
            if (v == null || !v.loaded || v.ReferenceTransform == null || v.mainBody == null) return prev;
            Vector3d up = (v.CoMD - v.mainBody.position).normalized;
            Vector3d north = Vector3d.Exclude(up,
                (v.mainBody.position + (Vector3d)v.mainBody.transform.up * v.mainBody.Radius) - v.CoMD).normalized;
            Vector3d east = Vector3d.Cross(up, north);
            Vector3d nose = v.ReferenceTransform.up;
            double nE = Vector3d.Dot(nose, east), nN = Vector3d.Dot(nose, north), nU = Vector3d.Dot(nose, up);

            if (v.situation == Vessel.Situations.PRELAUNCH) bearingSet = false;
            else if (!bearingSet && v.srfSpeed > 80.0 && v.altitude > 1000.0)
            {
                Vector3d sv = v.srf_velocity;
                double e = Vector3d.Dot(sv, east), n = Vector3d.Dot(sv, north);
                if (e * e + n * n > 2500.0) { downBearing = Math.Atan2(e, n); bearingSet = true; }
            }
            double bear = downBearing;
            if (!bearingSet && nE * nE + nN * nN > 0.01) bear = Math.Atan2(nE, nN);
            double fwd = nE * Math.Sin(bear) + nN * Math.Cos(bear);
            if (fwd * fwd + nU * nU < 1e-6) return prev;
            return (float)Math.Atan2(nU, fwd);
        }

        static bool SlotsUse(Metric m)
        {
            for (int i = 0; i < 4; i++) if (slots[i] == m) return true;
            return false;
        }

        void UpdateVData(VData d, Vessel v, double ut, bool wantNose)
        {
            if (v == null)
            {
                d.speedKmh = 0; d.altKm = 0; d.g = 0;
                d.pitch = Mathf.PI * 0.5f;
                return;
            }
            d.speedKmh = SpeedOfAny(v, ut);
            d.altKm = Math.Max(0.0, v.altitude / 1000.0);
            d.g = v.loaded ? v.geeForce : 0.0;
            if (wantNose) d.pitch = PitchOf(v, d.pitch);
        }

        // =====================================================================
        //  UPDATE
        // =====================================================================
        void Update()
        {
            if (Input.GetKeyDown(panelKey)) panelOpen = !panelOpen;
            ProcessPendingActions();

            Vessel active = FlightGlobals.ActiveVessel;
            if (active == null) return;

            double ut = Planetarium.GetUniversalTime();
            UpdateClock(active, ut);
            if (launched && events.Count > 0)
                for (int i = 0; i < events.Count; i++)
                    if (events[i].type == "liftoff" && events[i].actual < 0) events[i].actual = 0;

            if (Time.time >= nextScan)
            {
                nextScan = Time.time + (visible ? 0.2f : 0.5f);
                ScanVessels();
            }

            UpdateVData(bData, boosterV, ut, SlotsUse(Metric.BoosterAttitude));
            UpdateVData(sData, shipV != null ? shipV : active, ut, SlotsUse(Metric.ShipAttitude));

            DetectEvents(active);
        }

        void DetectEvents(Vessel active)
        {
            if (!launched || tPlus < 0) return;

            // MAX Q
            if (!Has("maxq"))
            {
                double q = active.dynamicPressurekPa;
                if (q > maxQ) maxQ = q;
                if (maxQ > 1.0 && q < maxQ * 0.9) SetActual("maxq");
            }

            // STAGE SEP : booster et ship ne sont plus le même véhicule (découpleur, port d'amarrage...)
            if (!Has("stagesep") && tPlus > 3.0 && boosterV != null && shipV != null && boosterV != shipV)
                SetActual("stagesep");

            if (Has("stagesep") && boosterV != null)
            {
                if (bLit == 0) boosterOffAfterSep = true;

                // BOOSTBACK START : les moteurs du booster se rallument après la séparation
                if (!Has("boostback") && boosterOffAfterSep && bLit > 0) SetActual("boostback");
                // BOOSTBACK SHUTDOWN
                else if (Has("boostback") && !Has("boostbackend") && bLit == 0 && tPlus > ActualOf("boostback") + 5.0)
                    SetActual("boostbackend");
                // LANDING BURN : nouvel allumage, en dessous de 25 km
                else if (Has("boostbackend") && !Has("landingburn") && bLit > 0 && boosterV.altitude < 25000.0)
                    SetActual("landingburn");
            }

            // SUPER HEAVY LANDING
            if (Has("stagesep") && !Has("boosterlanding") && boosterV != null)
            {
                Vessel bv = boosterV;
                bool down = bv.Landed || bv.Splashed;
                bool low = bv.loaded && bv.heightFromTerrain >= 0f && bv.heightFromTerrain < 80f &&
                           bv.srfSpeed < 10.0 && bv.verticalSpeed > -12.0;
                if (down || low) SetActual("boosterlanding");
            }

            // bascule automatique vers le format FLIGHT après le landing de Super Heavy
            if (autoFlightAfterLanding && !autoFlightDone && Has("boosterlanding"))
            {
                autoFlightDone = true;
                if (layoutPreset == LayoutPreset.Classic) ApplyPreset(LayoutPreset.Flight);
            }

            if (shipV != null)
            {
                Vessel sv = shipV;
                double atm = (sv.mainBody != null && sv.mainBody.atmosphere) ? sv.mainBody.atmosphereDepth : 0.0;
                int act = vacLit + slLit;

                if (Has("stagesep") && !Has("seco"))
                {
                    if (act > 0) litAfterSep = true;
                    if (litAfterSep && act == 0 && sv.altitude > atm) SetActual("seco");
                }
                if (Has("seco") && !Has("entry") && sv.altitude < atm && sv.verticalSpeed < 0) SetActual("entry");
                if (Has("entry") && !Has("landing") && (sv.Landed || sv.Splashed)) SetActual("landing");
            }

            AssumeOverdueEvents();
        }

        // =====================================================================
        //  MISE EN PAGE
        // =====================================================================
        void Layout()
        {
            W = Screen.width; H = Screen.height;
            s = Mathf.Min(W / 1920f, H / 1080f) * uiScale;
            baseY = H - 93f * s;
            R = 62f * s;        // unité du cluster Super Heavy
            U = 55.5f * s;      // unité du cluster Starship
            ringR = 68f * s;
            float m = slotMargin * s, step = 165f * s;
            sx[0] = m; sx[1] = m + step;
            sx[2] = W - (m + step); sx[3] = W - m;
            btnRect = new Rect(W - 64f * s, H - 34f * s, 24f * s, 22f * s);
        }

        // =====================================================================
        //  OnGUI
        // =====================================================================
        void OnGUI()
        {
            if (FlightGlobals.ActiveVessel == null) return;
            // F2 (interface masquée) : la télémétrie reste visible, sauf si hideWithF2 = true
            bool hudOn = visible && !(hideWithF2 && uiHidden);
            bool panelOn = panelOpen && !uiHidden;

            if (!hudOn && !panelOn)
            {
                if (inputLocked) { InputLockManager.RemoveControlLock(LockId); inputLocked = false; }
                return;
            }

            Layout();
            Event ev = Event.current;

            if (hudOn && !uiHidden && ev.type == EventType.MouseDown && ev.button == 0 && btnRect.Contains(ev.mousePosition))
            {
                panelOpen = !panelOpen;
                ev.Use();
            }

            if (hudOn && ev.type == EventType.Repaint && gfxOk) DrawHud();

            if (panelOn)
            {
                GUISkin old = GUI.skin;
                GUI.skin = HighLogic.Skin;
                windowRect = GUILayout.Window(WindowId, windowRect, DrawWindow, "Starship Telemetry - Control");
                GUI.skin = old;
                windowRect.x = Mathf.Clamp(windowRect.x, 0f, Mathf.Max(0f, Screen.width - 60f));
                windowRect.y = Mathf.Clamp(windowRect.y, 0f, Mathf.Max(0f, Screen.height - 40f));
            }

            bool over = panelOn && windowRect.Contains(ev.mousePosition);
            if (over != inputLocked)
            {
                if (over) InputLockManager.SetControlLock(ControlTypes.ALL_SHIP_CONTROLS, LockId);
                else InputLockManager.RemoveControlLock(LockId);
                inputLocked = over;
            }
        }

        // ---------------------------------------------------------------------
        void DrawHud()
        {
            RefreshClockStrings();
            float op = panelOpacity;
            gfx.S = s;
            gfx.Begin(W, H);

            // ---- ombre en bas + panneaux noirs à coin arrondi, symétriques ----
            gfx.SolidGrad(0, H - 260f * s, W, H, new Color(0, 0, 0, 0f), new Color(0, 0, 0, 0.60f * op));
            Color pTop = new Color(0.012f, 0.016f, 0.028f, 0.80f * op);
            Color pBot = new Color(0.006f, 0.008f, 0.014f, Mathf.Min(1f, 1.0f * op));
            float pH = 180f * s, pW = 500f * s, pY = H - pH;
            float cornerL = sx[1] + 120f * s;                 // coin haut du panneau gauche
            float x0L = cornerL - 352f * s;
            if (x0L > 0.5f) gfx.SolidGrad(0, pY, x0L + 1f, H, pTop, pBot);
            gfx.Panel(x0L, pY, x0L + pW, H, false, pTop, pBot);
            float cornerR = sx[2] - 120f * s;
            float x1R = cornerR + 352f * s;
            if (x1R < W - 0.5f) gfx.SolidGrad(x1R - 1f, pY, W, H, pTop, pBot);
            gfx.Panel(x1R - pW, pY, x1R, H, true, pTop, pBot);

            // ---- les 4 emplacements ----
            for (int i = 0; i < 4; i++) DrawMetric(slots[i], new Vector2(sx[i], baseY));

            // ---- noms des véhicules, sous les données ----
            if (showVehicleLabels)
            {
                DrawPairLabel(0, 1);
                DrawPairLabel(2, 3);
            }

            // ---- timeline courbe défilante ----
            DrawTimeline();

            // ---- chrono ----
            Color txt = white;
            Color soft = new Color(1f, 1f, 1f, 0.88f);
            float cx = W * 0.5f;
            float pxClock = 52f * s, pxT = 32f * s, gap = 9f * s;
            float wD = gfx.TextWidth(clockStr, pxClock, 0f);
            float wT = gfx.TextWidth(clockPrefix, pxT, 0f);
            float startX = cx - (wT + gap + wD) * 0.5f;
            gfx.Text(clockPrefix, startX + wT * 0.5f, baseY + 2f * s, pxT, soft, 0f, 0f, true);
            gfx.Text(clockStr, startX + wT + gap + wD * 0.5f, baseY + 2f * s, pxClock, txt, 0f, 0f, true);
            gfx.Text(flightNameUp, cx, baseY + 38f * s, 15.5f * s, soft, 1.7f * s, 0f, true);

            // ---- petit bouton discret (panneau de contrôle) ----
            if (!uiHidden)
            {
                bool hover = btnRect.Contains(Event.current.mousePosition);
                Color bc = new Color(1f, 1f, 1f, hover ? 0.95f : (panelOpen ? 0.75f : 0.35f));
                float bx = btnRect.x + 4f * s, by = btnRect.y + 5f * s;
                for (int i = 0; i < 3; i++)
                    gfx.Solid(bx, by + i * 5f * s, bx + 16f * s, by + i * 5f * s + 2f * s, bc);
            }

            gfx.End();
        }

        // 0 = aucun, 1 = booster, 2 = ship
        static int VehicleOf(Metric m)
        {
            if (m == Metric.None) return 0;
            return m >= Metric.BoosterGForce ? 1 : 2;
        }

        void DrawPairLabel(int a, int b)
        {
            int va = VehicleOf(slots[a]), vb = VehicleOf(slots[b]);
            if (va == 0 && vb == 0) return;
            float y = baseY + 78f * s;
            if (va == vb) VehicleLabel(va, (sx[a] + sx[b]) * 0.5f, y);
            else if (va == 0) VehicleLabel(vb, sx[b], y);
            else if (vb == 0) VehicleLabel(va, sx[a], y);
            else { VehicleLabel(va, sx[a], y); VehicleLabel(vb, sx[b], y); }
        }

        void VehicleLabel(int vehicle, float x, float y)
        {
            gfx.Text(vehicle == 1 ? "SUPER HEAVY" : "STARSHIP", x, y, 16f * s, white, 0.6f * s, 0f, true);
        }

        // ---------------------------------------------------------------------
        //  DONNÉES AFFICHABLES
        // ---------------------------------------------------------------------
        void DrawMetric(Metric m, Vector2 c)
        {
            if (m == Metric.None) return;
            bool boost = VehicleOf(m) == 1;
            VData d = boost ? bData : sData;

            switch (m)
            {
                case Metric.BoosterSpeed:
                    Gauge(c, d.speedKmh / boosterMaxSpeedKmh, "SPEED", d.sp.Int(d.speedKmh), "KM/H"); break;
                case Metric.ShipSpeed:
                    Gauge(c, d.speedKmh / shipMaxSpeedKmh, "SPEED", d.sp.Int(d.speedKmh), "KM/H"); break;
                case Metric.BoosterAltitude:
                    Gauge(c, d.altKm / boosterMaxAltKm, "ALTITUDE", d.alt.AltKm(d.altKm), "KM"); break;
                case Metric.ShipAltitude:
                    Gauge(c, d.altKm / shipMaxAltKm, "ALTITUDE", d.alt.AltKm(d.altKm), "KM"); break;
                case Metric.BoosterGForce:
                case Metric.ShipGForce:
                    Gauge(c, d.g / maxG, "G-FORCE", d.gt.Dec(d.g), "G"); break;
                case Metric.BoosterEngines: DrawBoosterEngines(c); break;
                case Metric.ShipEngines: DrawShipEngines(c); break;
                case Metric.BoosterAttitude:
                case Metric.ShipAttitude:
                    {
                        bool stack = boosterV != null && shipV != null && boosterV == shipV;   // avant la séparation : stack complet
                        DrawAttitude(c, d.pitch, stack ? 2 : (boost ? 1 : 0));
                        break;
                    }
            }
        }

        // Jauge : anneau (piste fine + remplissage épais) + libellé / valeur / unité
        void Gauge(Vector2 c, double frac, string label, string value, string unit)
        {
            Color track = new Color(1f, 1f, 1f, 0.34f);
            Color tick = new Color(1f, 1f, 1f, 0.95f);
            gfx.RingTrack(c, ringR, track);
            gfx.RingFill(c, ringR, (float)frac, white);
            gfx.Ticks(c, ringR, tick);

            float vpx = value.Length > 5 ? 36f * s : 42f * s;
            gfx.Text(label, c.x, c.y - 28f * s, 15.5f * s, new Color(1f, 1f, 1f, 0.90f), 0.4f * s, 0f, true);
            gfx.Text(value, c.x, c.y + 2f * s, vpx, white, 0f, 0f, true);
            gfx.Text(unit, c.x, c.y + 32f * s, 14f * s, new Color(1f, 1f, 1f, 0.90f), 0.4f * s, 0f, true);
        }

        void DrawBoosterEngines(Vector2 c)
        {
            Color track = new Color(1f, 1f, 1f, 0.34f);
            Color hair = new Color(1f, 1f, 1f, 0.42f);
            gfx.Disc(c, R * 0.98f, new Color(0f, 0f, 0f, 0.40f));
            gfx.RingHair(c, ringR, hair);
            gfx.RingTrack(c, ringR, track);
            gfx.RingFill(c, ringR, bFuel, white);
            gfx.Ticks(c, ringR, new Color(1f, 1f, 1f, 0.95f));
            float dotR = R * 0.091f;
            for (int i = 0; i < raptorPos.Length; i++)
                gfx.Disc(c + raptorPos[i] * R, dotR, bMask[i] ? white : dotOff);
        }

        void DrawShipEngines(Vector2 c)
        {
            Color track = new Color(1f, 1f, 1f, 0.34f);
            Color hair = new Color(1f, 1f, 1f, 0.42f);
            gfx.Disc(c, U * 1.02f, new Color(0f, 0f, 0f, 0.40f));
            gfx.RingHair(c, ringR, hair);
            gfx.RingTrack(c, ringR, track);
            gfx.RingFill(c, ringR, sFuel, white);
            gfx.Ticks(c, ringR, new Color(1f, 1f, 1f, 0.95f));
            for (int i = 0; i < 6; i++)
            {
                gfx.Disc(c + shipPos[i] * U, shipRad[i] * U, sMask[i] ? white : dotOff);
            }
        }

        // Icône d'inclinaison 2D (comme la télémétrie SpaceX) : cercle fin, ligne d'horizon, et la silhouette
        // du véhicule en traits blancs, tournée selon l'inclinaison du nez (0 = ship, 1 = booster, 2 = stack).
        void DrawAttitude(Vector2 c, float pitch, int kind)
        {
            float rc = 64f * s;     // rayon du cercle (RingHair 76.3 -> 64 px de design)

            gfx.Disc(c, rc, new Color(0f, 0f, 0f, 0.35f));
            gfx.RingHair(c, 76.3f * s, new Color(1f, 1f, 1f, 0.50f));

            Color hz = new Color(1f, 1f, 1f, 0.38f);
            gfx.AALine(new Vector2(c.x - rc * 0.88f, c.y), new Vector2(c.x + rc * 0.88f, c.y), 1.2f * s, hz, hz);

            DrawVehicle2D(c, rc, pitch, kind);
        }

        // ---------------------------------------------------------------------
        //  SILHOUETTES 2D (unités : demi-largeur du corps = 1 ; axe Y = nez, queue en Y = 0)
        // ---------------------------------------------------------------------
        class Shape2D
        {
            public readonly List<Vector2[]> polys = new List<Vector2[]>();   // pièces convexes (remplies + contour)
            public readonly List<Vector2[]> lines = new List<Vector2[]>();   // traits seuls (joints, repères)
            public float len;
        }

        static Shape2D[] shapes;
        static readonly float[] shapeLenFrac = { 0.75f, 0.82f, 0.84f };   // longueur / diamètre du cercle

        static Vector2[] Rect2(float x0, float y0, float x1, float y1)
        {
            return new Vector2[] { new Vector2(x0, y0), new Vector2(x1, y0), new Vector2(x1, y1), new Vector2(x0, y1) };
        }

        static Vector2[] Quad2(float ax, float ay, float bx, float by, float cx, float cy, float dx, float dy)
        {
            return new Vector2[] { new Vector2(ax, ay), new Vector2(bx, by), new Vector2(cx, cy), new Vector2(dx, dy) };
        }

        static Vector2[] Seg2(float x0, float y0, float x1, float y1)
        {
            return new Vector2[] { new Vector2(x0, y0), new Vector2(x1, y1) };
        }

        // corps + ogive (convexe) : de la queue (y0) à la pointe
        static Vector2[] BodyNose2(float y0, float yCyl, float yTip, float half)
        {
            List<Vector2> r = new List<Vector2>();
            r.Add(new Vector2(-half, y0));
            r.Add(new Vector2(half, y0));
            r.Add(new Vector2(half, yCyl));
            int n = 6;
            for (int k = 1; k < n; k++)
            {
                float t = (float)k / n;
                float w = half * Mathf.Pow(1f - Mathf.Pow(t, 1.5f), 0.75f);
                r.Add(new Vector2(w, yCyl + (yTip - yCyl) * t));
            }
            r.Add(new Vector2(0f, yTip));
            for (int k = n - 1; k >= 1; k--)
            {
                float t = (float)k / n;
                float w = half * Mathf.Pow(1f - Mathf.Pow(t, 1.5f), 0.75f);
                r.Add(new Vector2(-w, yCyl + (yTip - yCyl) * t));
            }
            r.Add(new Vector2(-half, yCyl));
            return r.ToArray();
        }

        // Starship seul (référence : icône SpaceX du ship) : 2 grands volets arrière, 2 petits volets avant, 2 joints
        static void BuildShip2D(Shape2D S)
        {
            for (int sg = -1; sg <= 1; sg += 2)
            {
                S.polys.Add(Quad2(sg * 1.0f, 0.33f, sg * 1.68f, 0.33f, sg * 1.62f, 1.45f, sg * 1.0f, 2.15f));
                S.polys.Add(Quad2(sg * 1.0f, 4.75f, sg * 1.80f, 4.90f, sg * 1.80f, 5.25f, sg * 1.0f, 5.45f));
            }
            S.polys.Add(BodyNose2(0f, 5.5f, 7.9f, 1.0f));
            S.lines.Add(Seg2(-1f, 1.2f, 1f, 1.2f));
            S.lines.Add(Seg2(-1f, 4.4f, 1f, 4.4f));
            S.len = 7.9f;
        }

        // Super Heavy seul : anneau de hot-stage en haut, joint, grille de contrôle d'un côté, jupe moteurs en bas
        static void BuildBooster2D(Shape2D S)
        {
            S.polys.Add(Rect2(1.0f, 1.2f, 1.7f, 4.6f));                 // grille de contrôle (un côté)
            S.polys.Add(Rect2(-1.0f, 0f, 1.0f, 12.2f));                 // corps
            S.polys.Add(Rect2(-1.12f, 12.2f, 1.12f, 12.7f));            // anneau de hot-stage
            S.polys.Add(Rect2(-1.15f, 0f, 1.15f, 0.3f));                // jupe moteurs
            S.lines.Add(Seg2(-1f, 7.0f, 1f, 7.0f));
            S.lines.Add(Seg2(-1.7f, 12.45f, 1.7f, 12.45f));             // repères du haut
            S.len = 12.7f;
        }

        // Stack complet (référence : icône SpaceX du stack) : booster + ship, très allongé
        static void BuildStack2D(Shape2D S)
        {
            S.polys.Add(Rect2(-1.85f, 0f, 1.85f, 6.9f));                // bas du booster (grilles / moteurs), plus large
            S.polys.Add(Rect2(-1.0f, 6.9f, 1.0f, 16.0f));               // corps du booster
            for (int sg = -1; sg <= 1; sg += 2)
            {
                S.polys.Add(Rect2(sg > 0 ? 1.0f : -2.25f, 16.2f, sg > 0 ? 2.25f : -1.0f, 18.4f));   // volets arrière du ship / anneau
                S.polys.Add(Quad2(sg * 1.0f, 24.9f, sg * 1.7f, 25.2f, sg * 1.7f, 26.0f, sg * 1.0f, 26.3f));   // petits volets avant
            }
            S.polys.Add(BodyNose2(16.0f, 26.0f, 28.9f, 1.0f));          // ship : corps + ogive
            S.lines.Add(Seg2(-1f, 10.5f, 1f, 10.5f));
            S.lines.Add(Seg2(-1f, 21.5f, 1f, 21.5f));
            S.len = 28.9f;
        }

        static void EnsureShapes()
        {
            if (shapes != null) return;
            shapes = new Shape2D[3];
            for (int k = 0; k < 3; k++) shapes[k] = new Shape2D();
            BuildShip2D(shapes[0]);
            BuildBooster2D(shapes[1]);
            BuildStack2D(shapes[2]);
        }

        void DrawVehicle2D(Vector2 c, float rc, float pitch, int kind)
        {
            EnsureShapes();
            Shape2D S = shapes[kind];

            Vector2 u = new Vector2(Mathf.Cos(pitch), -Mathf.Sin(pitch));     // direction de l'axe (queue -> nez) à l'écran
            if (gfx.HasIcon(kind))
            {
                // silhouette PNG extraite de la télémétrie SpaceX (intérieur sombre : masque l'horizon)
                gfx.Icon(kind, c, u, shapeLenFrac[kind] * 2f * rc, white);
                return;
            }
            float k = (shapeLenFrac[kind] * 2f * rc) / S.len;                 // pixels par unité de modèle
            Vector2 n = new Vector2(-u.y, u.x);                               // direction latérale
            float cy = S.len * 0.5f;

            Color fill = new Color(0.02f, 0.03f, 0.05f, 0.96f);               // masque la ligne d'horizon derrière le véhicule
            Color ink = new Color(1f, 1f, 1f, 0.95f);
            float lw = 1.5f * s;

            for (int i = 0; i < S.polys.Count; i++)
            {
                Vector2[] P = S.polys[i];
                Vector2 p0 = ModelToScreen(c, u, n, k, cy, P[0]);
                for (int j = 1; j + 1 < P.Length; j++)
                    gfx.Tri(p0, ModelToScreen(c, u, n, k, cy, P[j]), ModelToScreen(c, u, n, k, cy, P[j + 1]), fill);
            }
            for (int i = 0; i < S.polys.Count; i++)
            {
                Vector2[] P = S.polys[i];
                Vector2 prev = ModelToScreen(c, u, n, k, cy, P[P.Length - 1]);
                for (int j = 0; j < P.Length; j++)
                {
                    Vector2 cur = ModelToScreen(c, u, n, k, cy, P[j]);
                    gfx.AALine(prev, cur, lw, ink, ink);
                    prev = cur;
                }
            }
            Color inkSoft = new Color(1f, 1f, 1f, 0.80f);
            for (int i = 0; i < S.lines.Count; i++)
            {
                Vector2[] L = S.lines[i];
                gfx.AALine(ModelToScreen(c, u, n, k, cy, L[0]), ModelToScreen(c, u, n, k, cy, L[1]), lw * 0.85f, inkSoft, inkSoft);
            }
        }

        static Vector2 ModelToScreen(Vector2 c, Vector2 u, Vector2 n, float k, float cy, Vector2 m)
        {
            return c + u * ((m.y - cy) * k) + n * (m.x * k);
        }

        // ---------------------------------------------------------------------
        //  TIMELINE
        // ---------------------------------------------------------------------
        readonly Vector2[] curvePts = new Vector2[320];
        readonly float[] curveFade = new float[320];
        readonly int[] order = new int[64];

        static float Fade(float x, float a, float b, float f)
        {
            return Mathf.Clamp01((x - a) / f) * Mathf.Clamp01((b - x) / f);
        }

        // forme numériquement stable même quand le rayon tend vers l'infini (ligne droite)
        static float CurveY(float y0, float Rt, float dx)
        {
            float d = Mathf.Clamp(dx, -Rt * 0.95f, Rt * 0.95f);
            return y0 + d * d / (Rt + Mathf.Sqrt(Rt * Rt - d * d));
        }

        // Rayon de courbure : infini (ligne droite) au décollage, puis la courbe se creuse progressivement
        // (≈ rayon 8600 px à T+2:24, 1190 px à partir de T+6:20, comme sur la télémétrie SpaceX)
        float CurveRadius()
        {
            float f = 1f;
            if (curveAnimated)
            {
                float u = 0f;
                if (launched && tPlus > curveStartSec)
                    u = Mathf.Clamp01((float)((tPlus - curveStartSec) / Math.Max(1.0, curveEndSec - curveStartSec)));
                f = u * u;
            }
            return 1190f * s / Mathf.Max(f, 1e-4f);
        }

        void DrawTimeline()
        {
            float cx = W * 0.5f;
            float y0 = baseY - 61f * s;
            float Rt = CurveRadius();
            float pps = timelinePxPerSec * s;
            float xL = sx[1] + 130f * s;
            float xR = sx[2] - 130f * s;
            if (xR - xL < 100f * s) return;
            float fadeW = 70f * s;

            int n = Mathf.Min(curvePts.Length - 1, Mathf.CeilToInt((xR - xL) / (12f * s)));
            float step = (xR - xL) / n;
            for (int i = 0; i <= n; i++)
            {
                float x = xL + step * i;
                curvePts[i] = new Vector2(x, CurveY(y0, Rt, x - cx));
                curveFade[i] = Fade(x, xL, xR, fadeW);
            }

            // courbe secondaire fine, concentrique (comme la télémétrie SpaceX)
            if (secondCurve)
            {
                float Rt2 = Rt - 34f * s;
                Vector2 pp = Vector2.zero; float pf = 0f;
                for (int i = 0; i <= n; i++)
                {
                    float dx = curvePts[i].x - cx;
                    float dd = Mathf.Clamp(dx, -Rt2 * 0.95f, Rt2 * 0.95f);
                    Vector2 p = new Vector2(curvePts[i].x, y0 + 34f * s + dd * dd / (Rt2 + Mathf.Sqrt(Rt2 * Rt2 - dd * dd)));
                    if (i > 0)
                        gfx.AALine(pp, p, 1.3f * s, new Color(1f, 1f, 1f, 0.32f * pf), new Color(1f, 1f, 1f, 0.32f * curveFade[i]));
                    pp = p; pf = curveFade[i];
                }
            }

            float wMain = 2.8f * s;
            for (int i = 0; i < n; i++)
            {
                Color a = new Color(0f, 0f, 0f, 0.35f * curveFade[i]);
                Color b = new Color(0f, 0f, 0f, 0.35f * curveFade[i + 1]);
                gfx.AALine(curvePts[i], curvePts[i + 1], wMain + 3.2f * s, a, b);
            }
            for (int i = 0; i < n; i++)
            {
                float ba = curvePts[i].x <= cx ? 1.0f : 0.72f;
                float bb = curvePts[i + 1].x <= cx ? 1.0f : 0.72f;
                gfx.AALine(curvePts[i], curvePts[i + 1], wMain,
                           new Color(1f, 1f, 1f, ba * curveFade[i]), new Color(1f, 1f, 1f, bb * curveFade[i + 1]));
            }

            gfx.Solid(cx - 1.3f * s, y0 - 10f * s, cx + 1.3f * s, y0 + 10f * s, white);

            // jalons actifs, triés par temps : libellés alternés dessus / dessous
            int cnt = 0;
            for (int i = 0; i < events.Count && cnt < order.Length; i++)
            {
                if (!events[i].enabled) continue;
                int j = cnt++;
                double ti = EffTime(events[i]);
                while (j > 0 && EffTime(events[order[j - 1]]) > ti) { order[j] = order[j - 1]; j--; }
                order[j] = i;
            }

            Color dark = new Color(0.02f, 0.03f, 0.06f, 1f);
            for (int rank = 0; rank < cnt; rank++)
            {
                TLEvent e = events[order[rank]];
                double eff = EffTime(e);
                float x = cx + (float)(eff - tPlus) * pps;
                if (x < xL - 20f * s || x > xR + 20f * s) continue;

                float f = Fade(x, xL, xR, fadeW);
                if (f <= 0.01f) continue;
                float y = CurveY(y0, Rt, x - cx);
                bool reached = IsReached(e);
                float age = (float)(tPlus - eff);
                float na = reached ? Mathf.Clamp(1f - age / 500f, 0.55f, 1f) : 1f;

                // nœud : anneau fin ; point blanc au centre une fois atteint
                Vector2 pos = new Vector2(x, y);
                gfx.Disc(pos, 7.0f * s, new Color(1f, 1f, 1f, na * f));
                gfx.Disc(pos, 5.3f * s, new Color(dark.r, dark.g, dark.b, f));
                if (reached) gfx.Disc(pos, 2.2f * s, new Color(1f, 1f, 1f, na * f));

                float dx = Mathf.Clamp(x - cx, -Rt * 0.95f, Rt * 0.95f);
                float ang = Mathf.Atan(dx / Mathf.Sqrt(Rt * Rt - dx * dx));
                Vector2 nrm = new Vector2(Mathf.Sin(ang), -Mathf.Cos(ang));
                float off = (rank % 2 == 0) ? 23f * s : -23f * s;
                float la = reached ? Mathf.Clamp(1f - age / 220f, 0.30f, 1f) : 1f;
                Vector2 lp = pos + nrm * off;
                gfx.Text(e.nameUp, lp.x, lp.y, 15f * s, new Color(1f, 1f, 1f, la * f), 0.6f * s, ang * Mathf.Rad2Deg, true);
            }
        }

        // =====================================================================
        //  FENÊTRE DE CONTRÔLE
        // =====================================================================
        static bool TryParseTime(string t, out double seconds)
        {
            seconds = 0;
            if (string.IsNullOrEmpty(t)) return false;
            string[] parts = t.Trim().Split(':');
            double total = 0;
            for (int i = 0; i < parts.Length; i++)
            {
                double v;
                if (!double.TryParse(parts[i], NumberStyles.Float, CultureInfo.InvariantCulture, out v)) return false;
                total = total * 60.0 + v;
            }
            seconds = total;
            return true;
        }

        void FoldManual(double ut)
        {
            manBaseT = ManualValue(ut);
            manBaseUT = ut;
        }

        void DrawWindow(int id)
        {
            GUILayout.BeginVertical();
            panelTab = GUILayout.Toolbar(panelTab, tabNames);
            GUILayout.Space(4f);

            if (panelTab == 0) DrawTabClock();
            else if (panelTab == 1) DrawTabDisplay();
            else if (panelTab == 2) DrawTabEvents();
            else DrawTabTools();

            GUILayout.Space(6f);
            if (!gfxOk) GUILayout.Label("Render error: " + gfxError);
            if (GUILayout.Button("Save and close")) { SaveSettings(); panelOpen = false; }
            GUILayout.EndVertical();

            GUI.DragWindow();
        }

        void DrawTabClock()
        {
            double ut = Planetarium.GetUniversalTime();

            GUILayout.Label("Mission name (text under the clock)");
            string nn = GUILayout.TextField(flightName, 40);
            if (nn != flightName) SetFlightName(nn);

            GUILayout.Space(4f);
            GUILayout.Label("Telemetry clock");
            ClockMode before = clockMode;
            clockMode = (ClockMode)GUILayout.Toolbar((int)clockMode, modeNames);
            if (before != clockMode) OnModeChanged();

            GUILayout.Label("Shown: " + FormatClock(tPlus) + (launched ? "" : "   (waiting for liftoff)"));

            if (clockMode == ClockMode.Auto)
            {
                GUILayout.Label("T+ starts when the vehicle actually leaves the pad.");
                if (GUILayout.Button("Re-arm detection (reset T+)")) OnModeChanged();
            }
            else if (clockMode == ClockMode.GameMET)
            {
                GUILayout.Label("T+ = active vehicle MET (restarts from zero on a vehicle created by a separation).");
            }
            else
            {
                GUILayout.BeginHorizontal();
                GUILayout.Label("T-", GUILayout.Width(24f));
                tMinusInput = GUILayout.TextField(tMinusInput, 9, GUILayout.Width(90f));
                if (GUILayout.Button("Set"))
                {
                    double sec;
                    if (TryParseTime(tMinusInput, out sec)) { manBaseT = -Math.Abs(sec); manBaseUT = ut; manRunning = false; ResetEvents(); }
                }
                GUILayout.EndHorizontal();

                GUILayout.BeginHorizontal();
                if (GUILayout.Button(manRunning ? "Pause" : "Start"))
                {
                    FoldManual(ut);
                    manRunning = !manRunning;
                    manBaseUT = ut;
                }
                if (GUILayout.Button("GO (T+0)")) { manBaseT = 0; manBaseUT = ut; manRunning = true; ResetEvents(); }
                if (GUILayout.Button("Reset"))
                {
                    double sec;
                    if (!TryParseTime(tMinusInput, out sec)) sec = 600;
                    manBaseT = -Math.Abs(sec); manBaseUT = ut; manRunning = false; ResetEvents();
                }
                GUILayout.EndHorizontal();

                GUILayout.BeginHorizontal();
                if (GUILayout.Button("-1 min")) { FoldManual(ut); manBaseT -= 60; }
                if (GUILayout.Button("-10 s")) { FoldManual(ut); manBaseT -= 10; }
                if (GUILayout.Button("+10 s")) { FoldManual(ut); manBaseT += 10; }
                if (GUILayout.Button("+1 min")) { FoldManual(ut); manBaseT += 60; }
                GUILayout.EndHorizontal();
            }
        }

        void CycleSlot(int i, int dir)
        {
            int n = metricNames.Length;
            slots[i] = (Metric)(((int)slots[i] + dir + n) % n);
            layoutPreset = LayoutPreset.Custom;
        }

        void DrawTabDisplay()
        {
            GUILayout.Label("Format");
            LayoutPreset pb = layoutPreset;
            int sel = GUILayout.SelectionGrid((int)layoutPreset, presetNames, 1);
            if (sel != (int)pb)
            {
                if (sel == (int)LayoutPreset.Custom) layoutPreset = LayoutPreset.Custom;
                else ApplyPreset((LayoutPreset)sel);
            }

            GUILayout.Space(4f);
            GUILayout.Label("Displayed data (4 slots)");
            for (int i = 0; i < 4; i++)
            {
                GUILayout.BeginHorizontal();
                GUILayout.Label(slotNames[i], GUILayout.Width(120f));
                if (GUILayout.Button("<", GUILayout.Width(26f))) CycleSlot(i, -1);
                GUILayout.Label(metricNames[(int)slots[i]], GUILayout.Width(190f));
                if (GUILayout.Button(">", GUILayout.Width(26f))) CycleSlot(i, +1);
                GUILayout.EndHorizontal();
            }

            GUILayout.Space(4f);
            showVehicleLabels = GUILayout.Toggle(showVehicleLabels, " Show SUPER HEAVY / STARSHIP labels");
            autoFlightAfterLanding = GUILayout.Toggle(autoFlightAfterLanding, " Switch to Flight layout after Super Heavy landing");
            secondCurve = GUILayout.Toggle(secondCurve, " Thin secondary curve under the timeline");
            curveAnimated = GUILayout.Toggle(curveAnimated, " Straight timeline at liftoff, gradually curving");

            GUILayout.Space(4f);
            GUILayout.Label("Interface size: " + uiScale.ToString("F2", CultureInfo.InvariantCulture));
            uiScale = GUILayout.HorizontalSlider(uiScale, 0.6f, 1.6f);
            GUILayout.Label("Panel opacity: " + panelOpacity.ToString("F2", CultureInfo.InvariantCulture));
            panelOpacity = GUILayout.HorizontalSlider(panelOpacity, 0f, 1f);
        }

        void DrawTabEvents()
        {
            GUILayout.Label("Tick the milestones to display. The time (m:ss) is used until the milestone is detected in game.");
            evScroll = GUILayout.BeginScrollView(evScroll, GUILayout.Height(220f));
            for (int i = 0; i < events.Count; i++)
            {
                TLEvent e = events[i];
                GUILayout.BeginHorizontal();
                e.enabled = GUILayout.Toggle(e.enabled, "", GUILayout.Width(20f));
                string nm = GUILayout.TextField(e.name, 28, GUILayout.Width(170f));
                if (nm != e.name) { e.name = nm; e.nameUp = nm.ToUpperInvariant(); }
                string ts = GUILayout.TextField(e.timeStr, 8, GUILayout.Width(62f));
                if (ts != e.timeStr)
                {
                    e.timeStr = ts;
                    double v;
                    if (TryParseTime(ts, out v)) e.planned = Math.Max(0.0, v);
                }
                if (e.custom) { if (GUILayout.Button("x", GUILayout.Width(24f))) pendingRemove = i; }
                else GUILayout.Space(28f);
                GUILayout.EndHorizontal();
            }
            GUILayout.EndScrollView();

            GUILayout.Space(4f);
            GUILayout.Label("Add a custom milestone (name + time after liftoff)");
            GUILayout.BeginHorizontal();
            newEvName = GUILayout.TextField(newEvName, 28, GUILayout.Width(170f));
            newEvTime = GUILayout.TextField(newEvTime, 8, GUILayout.Width(62f));
            if (GUILayout.Button("+ Add")) pendingAdd = true;
            GUILayout.EndHorizontal();

            if (GUILayout.Button("Restore default milestones")) pendingRestoreEvents = true;
            if (GUILayout.Button("Reset detections")) ResetEvents();
        }

        void DrawTabTools()
        {
            bool nv = GUILayout.Toggle(visible, " Show telemetry on screen");
            if (nv != visible) { visible = nv; SyncButton(); }

            GUILayout.Space(4f);
            if (GUILayout.Button("Write detected engines to KSP.log")) DumpEngines();

            GUILayout.Space(4f);
            GUILayout.Label("Ship engine icon: real engine -> dot mapping (use if the wrong dot lights up)");
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Rotate (" + shipEngineRotate + ")")) { shipEngineRotate = (shipEngineRotate + 1) % 3; shipDotCache.Clear(); }
            bool nm = GUILayout.Toggle(shipEngineMirror, " Mirror");
            if (nm != shipEngineMirror) { shipEngineMirror = nm; shipDotCache.Clear(); }
            GUILayout.EndHorizontal();

            GUILayout.Space(4f);
            GUILayout.Label("Shortcut: " + panelKey.ToString() + "   |   small ≡ button at the bottom right of the overlay");
            GUILayout.Label("F2 does not hide the telemetry (hideWithF2 option in the cfg).");
            GUILayout.Label("Booster : " + (boosterV != null ? boosterV.vesselName : "not detected") + "  (engines lit: " + bLit + ")");
            GUILayout.Label("Ship : " + (shipV != null ? shipV.vesselName : "not detected") + "  (VAC " + vacLit + "/" + vacTotLast + ", SL " + slLit + "/" + slTotLast + ")");
        }

        // =====================================================================
        //  DEBUG : écrit dans KSP.log ce que le mod voit
        // =====================================================================
        void DumpEngines()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine("[StarshipTelemetry] ===== ENGINE DUMP =====");
            List<Vessel> loaded = FlightGlobals.VesselsLoaded;
            for (int vi = 0; vi < loaded.Count; vi++)
            {
                Vessel v = loaded[vi];
                if (v == null) continue;
                sb.AppendLine("Vessel: " + v.vesselName + "  parts=" + v.parts.Count + "  situation=" + v.situation +
                              "  packed=" + v.packed + "  mainThrottle=" + v.ctrlState.mainThrottle.ToString("F2"));
                for (int i = 0; i < v.parts.Count; i++)
                {
                    Part p = v.parts[i];
                    bool hasEngine = false;
                    for (int m = 0; m < p.Modules.Count; m++) if (p.Modules[m] is ModuleEngines) { hasEngine = true; break; }
                    if (!hasEngine) continue;

                    sb.AppendLine("  Part: title='" + (p.partInfo != null ? p.partInfo.title : "?") + "' name='" + p.name + "' kind=" + KindOf(p) + " dot=" + DotOf(p) +
                                  (shipAngDbg.ContainsKey(p.GetInstanceID()) ? " angle=" + shipAngDbg[p.GetInstanceID()].ToString("F0") : ""));
                    for (int m = 0; m < p.Modules.Count; m++)
                    {
                        ModuleEngines e = p.Modules[m] as ModuleEngines;
                        if (e == null) continue;
                        sb.Append("    engine id='" + e.engineID + "' units=" + EngineUnits(e) + " lit=" + IsLit(e, v) +
                                  " isEnabled=" + e.isEnabled + " ignited=" + e.EngineIgnited +
                                  " flameout=" + e.flameout + " throttle=" + e.currentThrottle.ToString("F2") +
                                  " maxThrust=" + e.maxThrust.ToString("F1") + " finalThrust=" + e.finalThrust.ToString("F1") +
                                  " thrustTransforms=" + (e.thrustTransforms != null ? e.thrustTransforms.Count : -1) + " props=");
                        if (e.propellants != null)
                            for (int k = 0; k < e.propellants.Count; k++) sb.Append(e.propellants[k].name + ",");
                        sb.AppendLine();
                    }
                }
            }
            sb.Append("   booster mask (33 dots, 1 = lit): ");
            for (int i = 0; i < 33; i++) sb.Append(bMask[i] ? '1' : '0');
            sb.AppendLine();
            sb.Append("   ship mask (VAC 0-2, SL 3-5): ");
            for (int i = 0; i < 6; i++) sb.Append(sMask[i] ? '1' : '0');
            sb.AppendLine();
            sb.AppendLine("=> BOOSTER: " + (boosterV != null ? boosterV.vesselName : "not detected") + "  lit=" + bLit + "  fuel=" + bFuel.ToString("F3"));
            sb.AppendLine("=> SHIP: " + (shipV != null ? shipV.vesselName : "not detected") + "  vac " + vacLit + "/" + vacTotLast + "  sl " + slLit + "/" + slTotLast + "  fuel=" + sFuel.ToString("F3"));
            Debug.Log(sb.ToString());
        }

        // =====================================================================
        //  GÉOMÉTRIE
        // =====================================================================
        // Ordre = ordre d'allumage : 3 = triangle ; 5 = triangle + gauche/droite ; 13 = triangle + anneau de 10 ; 33 = tous
        static Vector2[] BuildRaptorLayout()
        {
            Vector2[] l = new Vector2[33];
            int k = 0;
            l[k++] = Pt(0.147f, 300f); l[k++] = Pt(0.147f, 60f); l[k++] = Pt(0.147f, 180f);

            float[] mid = { 90f, 270f, 54f, 306f, 126f, 234f, 18f, 342f, 162f, 198f };
            for (int i = 0; i < mid.Length; i++) l[k++] = Pt(0.413f, mid[i]);

            for (int j = 0; j < 10; j++)
            {
                float a = 9f + 18f * j;
                l[k++] = Pt(0.690f, a);
                l[k++] = Pt(0.690f, 360f - a);
            }
            return l;
        }

        // angle en degrés, 0 = haut, sens horaire
        static Vector2 Pt(float r, float deg)
        {
            float a = deg * Mathf.Deg2Rad;
            return new Vector2(r * Mathf.Sin(a), -r * Mathf.Cos(a));
        }
    }
}
